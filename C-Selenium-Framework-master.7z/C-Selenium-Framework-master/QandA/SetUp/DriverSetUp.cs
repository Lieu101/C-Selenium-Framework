﻿using System;
using NUnit.Framework;
using NUnit.Framework.Interfaces;
using AventStack.ExtentReports;
using AventStack.ExtentReports.Reporter;
using Utilities;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Firefox;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using QandA;

namespace SetUp
{
    public class DriverSetUp
    {
        public IWebDriver driver;
        public WebDriverWait wait;

        public static ExtentReports extent;
        public static ExtentTest test;

        private string screenShotPath;
        private string projectPath;

        [OneTimeSetUp]
        //public void ReportSetUp()
        public void StartReport()
        {
            //To obtain the current solution path/project path
            string path = System.Reflection.Assembly.GetCallingAssembly().CodeBase;
            string actualPath = path.Substring(0, path.LastIndexOf("bin"));
            projectPath = new Uri(actualPath).LocalPath;
            //Append the html report file to current project path
            string reportPath = projectPath + @"TestReports\Reports\ExtentScreenShot.html";
            //string reportPath = projectPath + @"Reports\ExtentScreenShot.html";
            var report = new ExtentHtmlReporter(reportPath);
            extent = new ExtentReports();
            extent.AttachReporter(report);
        }

        [SetUp]
        public void Setup()
        {
            string role ="";
            switch (role)
            {
                case "POC":
                    role = @"https://itappst.frb.gov/faq/?testid=BOARD\POC1#/Y-14/Dashboard";
                    break;
                case "SME":
                    role = @"https://itappst.frb.gov/faq/?testid=BOARD\SME1#/Y-14/Dashboard";
                    break;
                case "Reviewer1":
                    role = @"https://itappst.frb.gov/fAq/?testid=BOARD\Reviewer1#/Y-14/Dashboard";
                    break;
                case "LReviewer1":
                    role = @"https://itappst.frb.gov/fAq/?testid=BOARD\LReviewer1#/Y-14/Dashboard";
                    break;
                default:
                    role = @"https://itappst.frb.gov/fAq/index.html#/Y-14/Dashboard";
                    break; 
            }


            string url = ConfigUtlis.GetValueFromConfig("url");
            string browser = ConfigUtlis.GetValueFromConfig("browser");
            BrowserLaunch(browser,  url);
        }

            //<add key = "role" value="Admin" />
            //<add key = "role" value="POC" />
            //<add key = "role" value="SME" />
            //<add key = "role" value="Reviewer1" />
            //<add key = "role" value="LReviewer1" />

        public void BrowserLaunch(string browser, string url)
        {
            if (browser.ToLower().Equals("Chrome") || browser.ToLower().Equals("ch"))
            {
                driver = new ChromeDriver();
            }
            else if (browser.ToLower().Equals("IE") || browser.ToLower().Equals("internet explorer"))
            {
                driver = new InternetExplorerDriver();
            }
            else if (browser.ToLower().Equals("Firefox") || browser.ToLower().Equals("FF"))
            {
                driver = new FirefoxDriver();
            }
            else
            {
                driver = new InternetExplorerDriver();
            }

            wait = new WebDriverWait(driver, TimeSpan.FromSeconds(60)); // Implicit Wait
            driver.Manage().Window.Maximize();
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            string zoomInJS = "document.body.style.zoom='100%'";
            js.ExecuteScript(zoomInJS);
            driver.Url = url;
        }



        //public void Setup()
        //{
        //    string url = ConfigUtlis.GetValueFromConfig("url");
        //    string browser = ConfigUtlis.GetValueFromConfig("browser");
        //    //driver = new ChromeDriver();
        //    //driver = new InternetExplorerDriver();

        //    wait = new WebDriverWait(driver, TimeSpan.FromSeconds(60)); // Implicit Wait
        //    driver.Manage().Window.Maximize();
        //    IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
        //    string zoomInJS = "document.body.style.zoom='100%'";
        //    js.ExecuteScript(zoomInJS);
        //    driver.Url = url;
        //}


        //public void BrowserLunch(string browser)
        //{
        //    if(browser.ToLower().Equals("Chrome") || browser.ToLower().Equals("ch"))
        //    {
        //        driver = new ChromeDriver();
        //    }
        //    else if (browser.ToLower().Equals("IE") || browser.ToLower().Equals("internet explorer"))
        //    {
        //        driver = new InternetExplorerDriver();
        //    }
        //    else if (browser.ToLower().Equals("Firefox") || browser.ToLower().Equals("FF"))
        //    {
        //        driver = new FirefoxDriver();
        //    }
        //    else
        //    {
        //        driver = new InternetExplorerDriver();
        //    }
        //}




        [TearDown]
        public void CloseBroser()
        {
            var status = TestContext.CurrentContext.Result.Outcome.Status;
            if(status == TestStatus.Failed)
            {
                string date = DateTime.Now.ToString().Replace('/' , '-').Replace(':', '-');
                screenShotPath = projectPath + @"TestReports\Reports\ScreenShot_" + date + ".png";
                screenShotPath = projectPath + @"TestReports\Reports\ScreenShot_" + date + ".png";

                var stackTrace = "<pre>" + TestContext.CurrentContext.Result.StackTrace + "pre/>";
                var erorMessage = TestContext.CurrentContext.Result.Message;

                Screenshot ss = ((ITakesScreenshot)driver).GetScreenshot();
                // if(driver != null)
                //Screenshot ss = (ITakesScreenshot).driver;
                //ts.GetScreenshot();

                ss.SaveAsFile(screenShotPath, ScreenshotImageFormat.Png);
                test.Log(Status.Fail, stackTrace + erorMessage);
                test.Log(Status.Fail, "Snapshot below: " + test.AddScreenCaptureFromPath(screenShotPath));
            }
            driver.Quit();

        }

        [OneTimeTearDown]
        //public void Final()
        public void EndReport()
        {
            extent.Flush();
        }
        
        // Added 11/04/2019
        public void SaveScreenShot(String testName)
        {
            String date = DateTime.Now.ToString().Replace('/', '-').Replace(':', '-');
            screenShotPath = projectPath + @"TestReports\Reports\ScreenShot_" + testName + "_" + date + ".png";
            // screenShotPath = projectPath + @"Reports\ScreenShot_" + testName + "_" + date + ".png";

            Screenshot ss = ((ITakesScreenshot)driver).GetScreenshot();
            ss.SaveAsFile(screenShotPath, ScreenshotImageFormat.Png);
        }
    }
}


//Add QA system info to html report
//extent.AddSystemInfo("Host Name", "Golam Kibria");
//extent.AddSystemInfo("Environment", "Test Environment");
//extent.AddSystemInfo("Username", "M3GMK00");