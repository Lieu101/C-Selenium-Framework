﻿using NUnit.Framework;
using QandA.Pages;
using SetUp;
using System;


namespace QandA.Test
{
    class SMEStgSearchTest : DriverSetUp
    {
        //========================================================
        [Test, Order(1), TestCase]
        public void SMEsearch()
        {
            try
            {
                //string trackingID = "Y140001515";
                string smeName = "Sam SME1";
                string smeAnswer = "Sam SME1 Answer: Looks OK";
                string smeComment = "Sam SME1 Comment: Looks Fine";

                test = extent.CreateTest("Stsrt SMEStgSearchTest");

                // Create a new Object for SearchPage to use their property
                SMEstagePage sme = new SMEstagePage(driver);

                //1 Click on 'ALL Q&As' Radio Button
                sme.ClickOnALLRadioBtn();

                //2 Click On "More Option" Search DropDown arrow
                sme.ClickOnmoreFewerOption();

                //3 Click On "Workflow Stage" DropDown arrow to Select Question Stages 
                sme.SelectWorkFlowSMEstage();

                //4  Type "Sam SME1" in SME Text Box 
                sme.TypeSMEName(smeName);

                //5 Click on Question Search Button
                sme.ClickOnSearchBtn();

                //6 Click on 1st row or 3rd value of Question Value_Link from the Search Results Table
                sme.CleckOnQuestionLink();

                //7 Click on Send to Business Reviewer Button  
                //sme.ClickOnBusinessReviewerButton();

                //8 Click on Close Button of "Missing criteria Message"
                //sme.CloseMissingCriteriaAlertMessage();

                //9 Click on Edit Answer Link text BOX
                sme.ClickOnEditAnswerLink();

                //10 Type SME Answer into "Answer" text BOX
                sme.TypeSMEAnswer(smeAnswer);

                //11 Click on Answer "Submit" Button
                sme.ClickOnAnswerSubmitBtn();

                //12 Click on "Add New Comment" Link text BOX
                sme.ClickOnAddANewCommentLink();

                //13 Type SME Comment into "Comment" text BOX
                sme.TypeSMEComment(smeComment);

                //14 Click on Answer "Submit" Button
                sme.ClickOnCommentSubmitBtn();

                //15 Click on "Send To Business Reviewer Button" 
                sme.ClickOnBusinessReviewerButton();

                //16 Store "Q&A Message : Question Y140001444 was updated successfully."
                sme.QuestionUpdatedMessage();

                //17 Click to Close Q&A Message : Question Y140001444 was updated successfully.
                sme.CloseQAMessageBox();

                //18 Click On LogOut Button
                sme.ClickOnLogOutButton();

                //12 Q&A Message : Question Y140001444 was updated successfully.
                sme.CloseQAMessageBox();

                //test.Log(Status.Pass, "End SearchByTrackingIdTest");  //ISSUE
                //Assert.IsTrue(driver.FindElement(By.XPath("trackingRowValueLoc")).Displayed);
                //driver.SwitchTo().Alert().Accept();
                //test.Log(AventStack.ExtentReports.Status.Pass, "End SME_Stage Test Pass");

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                test.Log(AventStack.ExtentReports.Status.Fail, "End SMEStgSearchTest");
                Assert.Fail();
            }
        }



        //========================================================
        [Test, Order(5), Ignore("SampleTestCaseName1")]
        public void SampleTestCaseName1()
        {
            try { }
            catch (Exception ex) { }
        }
        //========================================================

    }
}


/*
        [Test, Order(2), TestCaseSource("SMEStgSearchTest")]
        public void SMEsearch()
        {
            try
            {
                //string trackingID = "Y140001515";
                string smeName = "Sam SME1";
                string smeAnswer = "Sam SME1 Answer: Looks OK";
                string smeComment = "Sam SME1 Comment: Looks Fine";

                test = extent.CreateTest("Stsrt SMEStgSearchTest");

                // Create a new Object for SearchPage to use their property
                SMEstagePage sme = new SMEstagePage(driver);

                //1 Click on 'ALL Q&As' Radio Button
                sme.ClickOnALLRadioBtn();

                //2 Click On "More Option" Search DropDown arrow
                sme.ClickOnmoreFewerOption();

                //3 Click On "Workflow Stage" DropDown arrow to Select Question Stages 
                sme.SelectWorkFlowSMEstage();

                //4  Type "Sam SME1" in SME Text Box 
                sme.TypeSMEName(smeName);

                //5 Click on Question Search Button
                sme.ClickOnSearchBtn();

                //6 Click on 1st row or 3rd value of Question Value_Link from the Search Results Table
                sme.CleckOnQuestionLink();

                //7 Click on Send to Business Reviewer Button  
                //sme.ClickOnBusinessReviewerButton();

                //8 Click on Close Button of "Missing criteria Message"
                //sme.CloseMissingCriteriaAlertMessage();

                //9 Click on Edit Answer Link text BOX
                sme.ClickOnEditAnswerLink();

                //10 Type SME Answer into "Answer" text BOX
                sme.TypeSMEAnswer(smeAnswer);

                //11 Click on Answer "Submit" Button
                sme.ClickOnAnswerSubmitBtn();

                //12 Click on "Add New Comment" Link text BOX
                sme.ClickOnAddANewCommentLink();

                //13 Type SME Comment into "Comment" text BOX
                sme.TypeSMEComment(smeComment);

                //14 Click on Answer "Submit" Button
                sme.ClickOnCommentSubmitBtn();

                //15 Click on "Send To Business Reviewer Button" 
                sme.ClickOnBusinessReviewerButton();

                //16 Store "Q&A Message : Question Y140001444 was updated successfully."
                sme.QuestionUpdatedMessage();

                //17 Click to Close Q&A Message : Question Y140001444 was updated successfully.
                sme.CloseQAMessageBox();

                //18 Click On LogOut Button
                sme.ClickOnLogOutButton();

                //12 Q&A Message : Question Y140001444 was updated successfully.
                sme.CloseQAMessageBox();

                //test.Log(Status.Pass, "End SearchByTrackingIdTest");  //ISSUE
                //Assert.IsTrue(driver.FindElement(By.XPath("trackingRowValueLoc")).Displayed);
                //driver.SwitchTo().Alert().Accept();
                //test.Log(AventStack.ExtentReports.Status.Pass, "End SME_Stage Test Pass");

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                test.Log(AventStack.ExtentReports.Status.Fail, "End SMEStgSearchTest");
                Assert.Fail();
            }
        }
 
*/
