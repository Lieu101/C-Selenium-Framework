﻿using System;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.IE;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using System.Collections.Generic;
using System.Threading;
using SetUp;
using Utilities;
using Microsoft.CSharp.RuntimeBinder;
using PageObjects;
using QandA.Pages;

namespace QandA.Test
{
    public class CreateNewQuestionTest : DriverSetUp
    {
        //public IWebDriver driver { get; private set; }
        //private ChromeOptions options;
        //CreateNewQuestionPage ss = null;

        public static object[] CreateNewQuestionExcelData()
        {
            object[] main = ExcelUtlis.SheetIntoObject(@"C:\Users\M3GMK00\source\repos\QandA\QandA\TestData\QandATestData.xlsx", "NewQuestion");
            return main;
        }

        [Test, Order(1), TestCaseSource("CreateNewQuestionExcelData")]
        public void CreateQuestion(string firmNames, string firstNames, string lastNames, string emails, string phones, string originalQuestions, string answers, string comments,  string confidentiality, string series, string schedules, string subSchedules, string categorys, string impacts, string asOfDates, string confidentialityRequesteds)
        {
            try
            {
                //test = extent.CreateTest("CreateNewQuestionExcelTest");
                test = extent.CreateTest(TestContext.CurrentContext.Test.Name);

                //ss.ClickNewQuestion();
                driver.Manage().Window.Maximize();
                driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(60);

                CreateNewQuestionPage newQuestion = new CreateNewQuestionPage(driver);
                newQuestion.ClickNewQuestion();
                Thread.Sleep(3000);

                newQuestion.SelectConfidentialityRequested(confidentialityRequesteds);
                Thread.Sleep(2000);

                newQuestion.ClickOnSendToSME_ButtonLoc();
                Thread.Sleep(3000);
                newQuestion.GetTrackingID();
                Thread.Sleep(3000);
                newQuestion.CloseMissingCriteriaAlertMessage();
                Thread.Sleep(3000);

                //newQuestion.ClickOnToDay();
                //Thread.Sleep(3000);
                //newQuestion.ClickprimarySubmitterAddLink();
                //Thread.Sleep(5000);
                //newQuestion.SelectFirmNameDropDown(firmNames);
                //Thread.Sleep(3000);
                //newQuestion.TypeFirstName(firstNames);
                //Thread.Sleep(3000);
                //newQuestion.TypelastName(lastNames);
                //Thread.Sleep(3000);
                //newQuestion.TypeemailAddress(emails);
                //Thread.Sleep(3000);
                //newQuestion.TypePhoneNo(phones);
                //Thread.Sleep(3000);
                //newQuestion.ClickOnUpdateBtn();
                //Thread.Sleep(5000);
                //newQuestion.TypeOriginalQuestion(originalQuestions);
                //Thread.Sleep(2000);
                //newQuestion.TypeAnswer(answers);
                //Thread.Sleep(2000);
                //newQuestion.TypeComments(comments);
                //Thread.Sleep(3000);
                //newQuestion.SelectSeriesFromDropDown(series);
                //Thread.Sleep(1000);
                //newQuestion.SelectScheduleFromDropDown(schedules);
                //Thread.Sleep(2000);
                //newQuestion.SelectSubScheduleFromDropDown(subSchedules);
                //Thread.Sleep(2000);
                //newQuestion.SelectcategoryFromDropDown(categorys);
                //Thread.Sleep(2000);
                //newQuestion.ClickOnImpactCheckBox();
                //Thread.Sleep(2000);
                //newQuestion.SelectImpactsYearDropDown(impacts);
                //Thread.Sleep(1000);
                //newQuestion.SelectAsOfDateCheckBoxFromCheckBox(asOfDates);
                //Thread.Sleep(2000);

                //newQuestion.SelectConfidentialityRequested(confidentialityRequesteds);
                //Thread.Sleep(2000);

                //newQuestion.TypeConfidentialityRequestJustification(confidentiality);
                //Thread.Sleep(3000);
                //newQuestion.ClickOnSendToSME_ButtonLoc();
                //Thread.Sleep(3000);
                //newQuestion.GetTrackingID();
                //Thread.Sleep(3000);
                //newQuestion.CloseMissingCriteriaAlertMessage();

                ////driver.SwitchTo().Alert().Accept();

                //string expectTitle = "Q&A - Y14 Question";
                ////string actualTitle = driver.Title;
                ////Assert.AreEqual(expectTitle, actualTitle, "Assertion on Cerat New Question test");
                //DashboardPage dashboard = new DashboardPage(driver, wait);
                //string actualTitle =  dashboard.WaitFofLogOutPresentAndGetTitle();
                //Assert.AreEqual(expectTitle, actualTitle, "Assertion on Create New Question");
                //dashboard.ClickOnLogOut();

                ////test.Log(AventStack.ExtentReports.Status.Pass, "End CreateNewQuestionExcelData test Pass");
                //test.Log(AventStack.ExtentReports.Status.Pass, "Click on -" );


                //newQuestion.ClickNewQuestion();
                //Thread.Sleep(5000);
                //newQuestion.ClickOnSendToSME_ButtonLoc();
                //Thread.Sleep(3000);
                //newQuestion.ReadCriteriaAlertMessage();
                //Thread.Sleep(3000);
                //newQuestion.CloseMissingCriteriaAlertMessage();
                //Thread.Sleep(3000);

                //newQuestion.ClickConfidentiality();
                //Thread.Sleep(5000);
                //newQuestion.SendYes();
                //Thread.Sleep(5000);
                //newQuestion.SelectSeriesFromDropDown(series);
                //Thread.Sleep(1000);
                //newQuestion.SelectScheduleFromDropDown(schedules);
                //Thread.Sleep(1000);
                //newQuestion.SelectSubScheduleFromDropDown(subSchedules);
                //Thread.Sleep(1000);
                //newQuestion.SelectcategoryFromDropDown(categorys);
                //Thread.Sleep(1000);
                //newQuestion.ClickOnImpactCheckBox();
                //Thread.Sleep(1000);
                //newQuestion.SelectImpactsYearDropDown(impacts);
                //Thread.Sleep(1000);
                //newQuestion.SelectAsOfDateCheckBoxFromCheckBox(asOfDates);
                //Thread.Sleep(1000);
                //newQuestion.ClickOnSendToSME_ButtonLoc();
                //Thread.Sleep(3000);
                //newQuestion.MissingCriteriaAlertMessage();
                //Thread.Sleep(3000);
                //newQuestion.SelectConfidentialityRequested(confidentialityRequesteds);
                //newQuestion.SelectSeriesFromDropDown(series);
                //newQuestion.SelectAsOfDateCheckBoxFromCheckBox(asOfDates);
                //newQuestion.TypeConfidentialityRequestJustification(confidentiality);
                //Thread.Sleep(3000);
                //driver.Close();
                //driver.Quit();

            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                test.Log(AventStack.ExtentReports.Status.Fail, "CreateNewQuestionExcelData test Failed");
                Assert.Fail();
                                                                                                                                                                                                                                                                                                                            
            }



        }








        //string url = @"https://itappst.frb.gov/faq/?testid=BOARD\POC1#/Y-14/Dashboard";
        //options = new ChromeOptions();
        //options.AddAdditionalCapability("useAutomationExtension", false);
        //driver = new ChromeDriver(options);
        //IWebDriver driver = new ChromeDriver();
        //driver.Navigate().GoToUrl(url);
        //driver.Manage().Window.Maximize();
        //driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(60);

        //InternetExplorerOptions options = new InternetExplorerOptions();
        //options.AddAdditionalCapability("useAutomationExtension", false);
        //IWebDriver driver = new InternetExplorerDriver(options);

        /*
        IJavaScriptExecutor js =(IJavaScriptExecutor) driver;
        IWebElement yourAccEle = driver.FindElement(By.XPath("//atext()='YourAccount'"));
        js.ExecuteScript("arguments0.click();", yourAccEle);
        */

        /*IWebElement addNewQuestion = driver.FindElement(By.XPath("//div[@class='row']//h2//a")); 
         / html / body / div[3] / div[1] / div[1] / div[3] / h2 / a
        IWebElement addNewQuestion = driver.FindElement(By.CssSelector("h2 > a")); */

        //IWebElement addNewQuestion = driver.FindElement(By.XPath("//h2/a"));
        //Thread.Sleep(5000);
        //addNewQuestion.Click();

        //Date and Time Question Received
        //IWebElement dateAndTime =  driver.FindElement(By.XPath("//*[@id='dateQuestionReceivedDiv']/span/span"));
        //IWebElement dateAndTime = driver.FindElement(By.XPath("(//span[@class='glyphicon glyphicon-calendar'])[2]"));
        //Thread.Sleep(10000);
        //dateAndTime.Click();

        //* Click Today
        //IWebElement toDay = driver.FindElement(By.XPath("/html/body/div[8]/div[3]/table/tfoot/tr/th"));
        //IWebElement toDayEle1 = driver.FindElement(By.XPath("(//th[@class='today'])[18]"));
        //Thread.Sleep(5000);
        //toDayEle1.Click();

        //* Type primary Submitter
        //IWebElement primarySubmitter = driver.FindElement(By.XPath("//*[@id='contacts-collapse']/div[3]/div[2]/div[1]/div[2]/a"));
        //IWebElement primarySubmitterEle = driver.FindElement(By.XPath("(//a[text()='add'])[3]"));
        //Thread.Sleep(1000);
        //primarySubmitter.Click();

        //* Click on add a New Question Link
        //IWebElement addNewQuestionEle = driver.FindElement(By.XPath("//h2/a"));
        //js.ExecuteScript("arguments[0].click();", addNewQuestionEle);

        //* Click on ToDay 
        //IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
        //IWebElement toDayEle = driver.FindElement(By.XPath("(//th[@class='today'])[18]"));
        //Thread.Sleep(5000);
        //js.ExecuteScript("arguments[0].click();", toDayEle);

        //* Type Primary Submitter
        //IWebElement primarySubmitterEle = driver.FindElement(By.XPath("(//a[text()='add'])[3]"));
        //Thread.Sleep(1000);
        //js.ExecuteScript("arguments[0].click();", primarySubmitterEle);











        [Test, Order(2), Ignore("Error")]
        public void CreateANewQuestion()
        {
            string firstName = "Rehina";
            string lastName = "Arina";
            string phoneNumber = "2025558876";
            string Url = @"https://itappst.frb.gov/faq/?testid=BOARD\POC1#/Y-14/Dashboard";

            InternetExplorerOptions options = new InternetExplorerOptions();
            options.AddAdditionalCapability("useAutomationExtension", false);
            IWebDriver driver = new InternetExplorerDriver(options);

            //IWebDriver driver = new ChromeDriver(options);
            //IWebDriver driver = new FirefoxDriver(options)


            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(60);
            driver.Navigate().GoToUrl(Url);
            driver.Manage().Window.Maximize();
            Thread.Sleep(10000);

            //List<string> textToFindAncors = new List<string>();
            //ReadOnlyCollection<IWebElement> ancorLists = driver.FindElements(By.XPath("a"));
            //foreach (IWebElement ancor in ancorLists)
            //{
            //    Console.WriteLine(ancor);
            //}
            //Thread.Sleep(10000);


            //* Click to Add a new Question
            IWebElement addNewQuestion = driver.FindElement(By.XPath("//div[@class='row']//h2//a"));
            //IWebElement addNewQuestion = driver.FindElement(By.XPath("(//a[contains(text(),'Add New Question')])[2]"));
            Thread.Sleep(1000);
            addNewQuestion.Click();  //ISSUE to Click

            //Date and Time Question Received
            //IWebElement dateAndTime =  driver.FindElement(By.XPath("//*[@id='dateQuestionReceivedDiv']/span/span"));
            IWebElement dateAndTime = driver.FindElement(By.XPath("(//span[@class='glyphicon glyphicon-calendar'])[2]"));
            Thread.Sleep(10000);
            dateAndTime.Click();

            //* Click Today
            //IWebElement toDay = driver.FindElement(By.XPath("/html/body/div[8]/div[3]/table/tfoot/tr/th"));
            IWebElement toDay = driver.FindElement(By.XPath("(//th[@class='today'])[18]"));
            Thread.Sleep(5000);
            toDay.Click();

            //* Type primary Submitter
            //IWebElement primarySubmitter = driver.FindElement(By.XPath("//*[@id='contacts-collapse']/div[3]/div[2]/div[1]/div[2]/a"));
            IWebElement primarySubmitter = driver.FindElement(By.XPath("(//a[text()='add'])[3]"));
            Thread.Sleep(1000);
            primarySubmitter.Click();

            //-----------------------------------------------------------------------------------------------------------------------------------
            //* Select  FIRM NAME '48TH ST BR' from Dropdown List
            IWebElement firmName = driver.FindElement(By.XPath("//*[@id='SubmitterPrimaryFirmId']/option[9]"));
            Thread.Sleep(5000);
            firmName.Click();

            //* Type  First Name          
            IWebElement firstNAME = driver.FindElement(By.XPath("//*[@id='SubmitterPrimaryGivenName']"));
            //Thread.Sleep(5000);
            firstNAME.SendKeys(firstName);

            //* Type  Last Name 
            IWebElement lastNAME = driver.FindElement(By.XPath("//*[@id='SubmitterPrimarySurName']"));
           // Thread.Sleep(1000);
            lastNAME.SendKeys(lastName);

            //* Type  email Address 
            IWebElement emailAddress = driver.FindElement(By.XPath("//*[@id='SubmitterPrimaryEmail']"));
            Thread.Sleep(5000);
            emailAddress.SendKeys(firstName + "." + lastName + "@frb.gov");

            //* Type  phone Number 
            IWebElement phoneNUMBER = driver.FindElement(By.XPath("//*[@id='SubmitterPrimaryPhone']"));
            phoneNUMBER.SendKeys(phoneNumber);

            //* Click on Update Button
            IWebElement updateButton = driver.FindElement(By.XPath("//*[@id='PrimarySubmitterForm']/div[2]/button[2]"));
            updateButton.Click();

            //-----------------------------------------------------------------------------------------------------------------------------------
            //* Select Program/ Series from Dropdown List
            IWebElement selectFRY14A = driver.FindElement(By.XPath("//*[@id='Series']/option[2]"));
            Thread.Sleep(9000);
            selectFRY14A.Click();

            //IWebElement selectFRY14Q = driver.FindElement(By.XPath("//*[@id='Series']/option[3]"));
            //selectFRY14Q.Click();
            //IWebElement selectFRY14M = driver.FindElement(By.XPath("//*[@id='Series']/option[4]"));
            //selectFRY14M.Click();

            //IList<IWebElement> all = driver.FindElements(By.XPath("comments"));

            //String[] allText = new String[all.Count];
            //int i = 0;
            //foreach (IWebElement element in all)
            //{
            //    allText[i++] = element.Text;
            //}



            //* Select Schedule from Dropdown List
            IWebElement selectScheduleASummary = driver.FindElement(By.XPath("//*[@id='Schedule']/option[3]"));
            selectScheduleASummary.Click();

            //* Select Sub-Schedule 'A.1.B Balance Sheet' from Dropdown List
            IWebElement selectSubScheduleBalanceSheet = driver.FindElement(By.XPath("//*[@id='SubSchedule']/option[4]"));
            selectSubScheduleBalanceSheet.Click();

            //* Select Category 'PPNR ' from Dropdown List
            IWebElement selectCategoryPPNR = driver.FindElement(By.XPath("//*[@id='Category']/option[16]"));
            selectCategoryPPNR.Click();

            //* Select As Of Date '2019 Q4' from CheckBoxes 
            IWebElement selectAsOfDate = driver.FindElement(By.XPath("(//*[@id='as-of-date2']/label/input)[2]"));
            selectAsOfDate.Click();

            //* Type Original Question in the text panel
            IWebElement originalQuestion = driver.FindElement(By.XPath("//*[@id='OriginalQuestion']"));
            originalQuestion.SendKeys("Test Question 1");

            //* Type Answer in the text panel
            IWebElement answer = driver.FindElement(By.XPath("//*[@id='Answer']"));
            answer.SendKeys("POC1 Open a new question");

            //* Type Comment in the text panel
            IWebElement comments = driver.FindElement(By.XPath("//*[@id='Comments']"));
            comments.SendKeys("POC1 Open a new question");



            //* Select Confidentiality Requested 'YES/NO' from Dropdown List
            IWebElement confidentialityRequested = driver.FindElement(By.XPath("//*[@id='FirmSpecific']/option[2]"));
            confidentialityRequested.Click();


            //* Type Confidentiality Request Justification comment
            IWebElement confidentialityComments = driver.FindElement(By.XPath("//textarea[starts-with(@aria-label, 'Confidentiality Request Justification']"));
            confidentialityComments.SendKeys("POC1 Confidentiality Request Justification comment");

            //* Click Confidentiality Request Justification Upload Attachment link
            IWebElement clickUploadAttachment = driver.FindElement(By.XPath("//a[starts-with(@id, 'upload_link']"));
            clickUploadAttachment.Click();

            //* Select a file to Upload an Attachment
            //IWebElement selectAttachment = driver.FindElement(@"C:\Users\M3GMK00\Desktop\POC1 Attached Files\POC6.xlsx").Click();



            //@"C: \Users\M3GMK00\Desktop\POC1 Attached Files\POC6.xlsx"


         //a[@id='upload_linkD']

         //* Click 'Send to SME' Button
         IWebElement sendToSMEButton = driver.FindElement(By.XPath("/html/body/div[3]/div[1]/div/form/div[4]/div[2]/div[5]/div/div/div[2]/table/tbody/tr/td/div/button"));
            sendToSMEButton.Click();

            driver.Close();
            driver.Quit();
        }

    }
}






