﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.IE;
using System;
using System.Threading;
//using OpenQA.Selenium.Chrome.ChromeOptions;

namespace QandA.Test
{
    public class InternetExplorerTest
    {
        [Test]
        public void IEDriver()
        {
            string firstName = "John";
            string lastName = "Smith";
            string phoneNumber = "2026097768";
            string Url = @"https://itappst.frb.gov/faq/?testid=BOARD\POC1#/Y-14/Dashboard";

            //ChromeOptions options = new ChromeOptions();
            //options.AddAdditionalCapability("useAutomationExtension", false);
            //IWebDriver driver = new ChromeDriver(options);
            //IWebDriver driver = new FirefoxDriver
            //IWebDriver driver = new ChromeDriver();

            IWebDriver driver = new InternetExplorerDriver();
            driver.Navigate().GoToUrl(Url);
            driver.Manage().Window.Maximize();
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(40);


            //* Click to Add a new Question
            IWebElement addNewQuestion = driver.FindElement(By.XPath("(//a[contains(.,'Add New Question')])[2]"));
            //Thread.Sleep(1000);
            addNewQuestion.Click();

            //Date and Time Question Received
            //IWebElement dateAndTime =  driver.FindElement(By.XPath("//*[@id='dateQuestionReceivedDiv']/span/span"));
            IWebElement dateAndTime = driver.FindElement(By.XPath("(//span[@class='glyphicon glyphicon-calendar'])[2]"));
            Thread.Sleep(10000);
            dateAndTime.Click();

            //* Click Today
            //IWebElement toDay = driver.FindElement(By.XPath("/html/body/div[8]/div[3]/table/tfoot/tr/th"));
            IWebElement toDay = driver.FindElement(By.XPath("(//th[@class='today'])[18]"));
            Thread.Sleep(5000);
            toDay.Click();

            //* Type primary Submitter
            //IWebElement primarySubmitter = driver.FindElement(By.XPath("//*[@id='contacts-collapse']/div[3]/div[2]/div[1]/div[2]/a"));
            IWebElement primarySubmitter = driver.FindElement(By.XPath("(//a[text()='add'])[3]"));
            //Thread.Sleep(1000);
            primarySubmitter.Click();

            //-----------------------------------------------------------------------------------------------------------------------------------
            //* Select  FIRM NAME '48TH ST BR' from Dropdown List
            IWebElement firmName = driver.FindElement(By.XPath("//*[@id='SubmitterPrimaryFirmId']/option[9]"));
            Thread.Sleep(5000);
            firmName.Click();

            //* Type  First Name          
            IWebElement firstNAME = driver.FindElement(By.XPath("//*[@id='SubmitterPrimaryGivenName']"));
            //Thread.Sleep(5000);
            firstNAME.SendKeys(firstName);

            //* Type  Last Name 
            IWebElement lastNAME = driver.FindElement(By.XPath("//*[@id='SubmitterPrimarySurName']"));
            // Thread.Sleep(1000);
            lastNAME.SendKeys(lastName);

            //* Type  email Address 
            IWebElement emailAddress = driver.FindElement(By.XPath("//*[@id='SubmitterPrimaryEmail']"));
            Thread.Sleep(5000);
            emailAddress.SendKeys(firstName + "." + lastName + "@frb.gov");

            //* Type  phone Number 
            IWebElement phoneNUMBER = driver.FindElement(By.XPath("//*[@id='SubmitterPrimaryPhone']"));
            phoneNUMBER.SendKeys(phoneNumber);

            //* Click on Update Button
            IWebElement updateButton = driver.FindElement(By.XPath("//*[@id='PrimarySubmitterForm']/div[2]/button[2]"));
            updateButton.Click();

            //-----------------------------------------------------------------------------------------------------------------------------------


            //* Select Program/ Series from Dropdown List
            IWebElement selectFRY14A = driver.FindElement(By.XPath("//*[@id='Series']/option[2]"));
            Thread.Sleep(9000);
            selectFRY14A.Click();

            //IWebElement selectFRY14Q = driver.FindElement(By.XPath("//*[@id='Series']/option[3]"));
            //selectFRY14Q.Click();
            //IWebElement selectFRY14M = driver.FindElement(By.XPath("//*[@id='Series']/option[4]"));
            //selectFRY14M.Click();


            //* Select Schedule from Dropdown List
            IWebElement selectScheduleASummary = driver.FindElement(By.XPath("//*[@id='Schedule']/option[3]"));
            selectScheduleASummary.Click();

            //* Select Sub-Schedule 'A.1.B Balance Sheet' from Dropdown List
            IWebElement selectSubScheduleBalanceSheet = driver.FindElement(By.XPath("//*[@id='SubSchedule']/option[4]"));
            selectSubScheduleBalanceSheet.Click();

            //* Select Category 'PPNR ' from Dropdown List
            IWebElement selectCategoryPPNR = driver.FindElement(By.XPath("//*[@id='Category']/option[16]"));
            selectCategoryPPNR.Click();

            //* Select As Of Date '2019 Q4' from CheckBoxes 
            IWebElement selectAsOfDate = driver.FindElement(By.XPath("(//*[@id='as-of-date2']/label/input)[2]"));
            selectAsOfDate.Click();

            //* Type Original Question in the text panel
            IWebElement originalQuestion = driver.FindElement(By.XPath("//*[@id='OriginalQuestion']"));
            originalQuestion.SendKeys("Test Question 1");

            //* Type Answer in the text panel
            IWebElement answer = driver.FindElement(By.XPath("//*[@id='Answer']"));
            answer.SendKeys("POC1 Open a new question");

            //* Type Comment in the text panel
            IWebElement comments = driver.FindElement(By.XPath("//*[@id='Comments']"));
            comments.SendKeys("POC1 Open a new question");


            //* Select Confidentiality Requested 'YES/NO' from Dropdown List
            IWebElement confidentialityRequested = driver.FindElement(By.XPath("//*[@id='FirmSpecific']/option[2]"));
            confidentialityRequested.Click();


            //* Type Confidentiality Request Justification comment
            IWebElement confidentialityComments = driver.FindElement(By.XPath("//textarea[starts-with(@aria-label, 'Confidentiality Request Justification']"));
            confidentialityComments.SendKeys("POC1 Confidentiality Request Justification comment");

            //* Click Confidentiality Request Justification Upload Attachment link
            IWebElement clickUploadAttachment = driver.FindElement(By.XPath("//a[starts-with(@id, 'upload_link']"));
            clickUploadAttachment.Click();

            //* Select a file to Upload an Attachment
            //IWebElement selectAttachment = driver.FindElement(@"C:\Users\M3GMK00\Desktop\POC1 Attached Files\POC6.xlsx").Click();

            //* Click 'Send to SME' Button
            IWebElement sendToSMEButton = driver.FindElement(By.XPath("/html/body/div[3]/div[1]/div/form/div[4]/div[2]/div[5]/div/div/div[2]/table/tbody/tr/td/div/button"));
            sendToSMEButton.Click();

            driver.Close();
            driver.Quit();



        }
    }
}
