﻿using System;
//using System.Data;
using Excel = Microsoft.Office.Interop.Excel;
using Microsoft.Office.Interop.Excel;
using NUnit.Framework;


namespace QandA.Test
{
    class MyTestDataTest
    {
        [Test]
        public void TestDataTest()
        {

        }

    }
}





/*
             
             string path = @"C:\Users\M3GMK00\Desktop\TestDataSelenium\Test1.xlsx";
             string sheetName = "TestDT1";

            Excel.Application app = new Excel.Application();
            Excel.Workbook book = app.Workbooks.Open(path);
            Excel.Worksheet sheet = book.Sheets[sheetName];
            
            Excel.Range range = sheet.UsedRange;
            int rowCount = range.Rows.Count;
            int columnCount = range.Columns.Count;

            DataTable dt = new DataTable();
            //Fill the column header from Excel to DataTable
            for (int j = 1; j <= columnCount; j++)
            {
                String columnHeader = range.Cells[1, j].value;
                dt.Columns.Add(columnHeader);
            }
            // Fill the row in the DataTable
            for (int i = 2; i <= rowCount; i++)
            {
                DataRow row = dt.NewRow();
                for (int j = 1; j <= columnCount; j++)
                {
                    String cellValue = range.Cells[i, j].value;
                    row[j - 1] = cellValue;
                    Console.WriteLine(cellValue);
                }
                dt.Rows.Add(row);
            }

            //book.Save();
            book.Close();
            app.Quit();

 */
