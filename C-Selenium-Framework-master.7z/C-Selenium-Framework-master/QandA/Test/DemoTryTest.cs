﻿using System;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.IE;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using System.Collections.Generic;
using System.Threading;
using AventStack.ExtentReports;
using QandA.Pages;
using SetUp;

namespace QandA.Test
{
    public class DemoTryTest : DriverSetUp
    {
        [Test, Order(1)]
        public void ChromeDriver()
        {
            try
            {
                string url = @"https://itappst.frb.gov/fAq/index.html#/Y-14/Dashboard";

                IWebDriver driver = new FirefoxDriver();
                driver.Navigate().GoToUrl(url);
                driver.Manage().Window.Maximize();
                driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(60);

                //* Click to Add a new Question
                IWebElement addNewQuestion = driver.FindElement(By.LinkText("Add New Question"));
                string text = addNewQuestion.Text;
                addNewQuestion.Click();
                Thread.Sleep(3000);
                IWebElement originalQuestionLoc = driver.FindElement(By.Id("OriginalQuestion]"));
                Thread.Sleep(3000);
                originalQuestionLoc.SendKeys("Original question 1");

                IWebElement answerLoc = driver.FindElement(By.Id("Answer"));
                answerLoc.SendKeys("answer lfk ");
                Thread.Sleep(3000);


                driver.Close();
                driver.Quit();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }


        }
    }
}
