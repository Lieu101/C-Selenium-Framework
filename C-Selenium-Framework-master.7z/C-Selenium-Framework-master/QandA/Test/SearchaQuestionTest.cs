﻿using System;
using System.Threading;
using NUnit.Framework;
using PageObjects;
using Utilities;
using SetUp;
using AventStack.ExtentReports;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using System.Collections.Generic;
using QandA.Pages;

namespace QandA.Test
{
    public class SearchaQuestionTest : DriverSetUp
    {
        public static object[] SearchByTrackingIdData()
        {
            object[] main = ExcelUtlis.SheetIntoObject(@"C:\Users\M3GMK00\source\repos\QandA\QandA\TestData\QandATestData.xlsx", "TrackingID");
            return main;
        }
        //=======================================================================================================================================

        //[Test, Order(1), Ignore("SearchByTrackingIdData")]
        [Test, Order(1), TestCaseSource("SearchByTrackingIdData")]
        public void FindByTrackingID(string trackingIds)
        {
            try
            {
                string expectTitle = "Q&A - Y14 Dashboard";

                test = extent.CreateTest("Search By TrackingId Test");

                SearchPage search = new SearchPage(driver);
                search.ClickOnAllQARadioBtn();
                test.Log(Status.Info, "Click On AllQARadio Button");
                search.EnterTrackingID(trackingIds);
                Thread.Sleep(5000);
                test.Log(Status.Info, "Entered Tracking ID: " + trackingIds);
                search.ClickOnSearchBtn();
                test.Log(Status.Info, "Click On Search Button");

                DashboardPage dashboard = new DashboardPage(driver, wait);

                string actualTitle = dashboard.WaitForLogOutPresentAndGetTitle();
                Assert.AreEqual(expectTitle, actualTitle, "Assertion on Create New Question");
                test.Log(Status.Info, "Actual Page Title is : " + actualTitle);

                //dashboard.ClickOnLogOut();
                search.ClickOnLogOutBtn();

                test.Log(Status.Info, "Successfully Logout from application");
                test.Log(Status.Pass, "End Search By TrackingId Test");
                SaveScreenShot("SearchByTrackingIdData");

            }
            catch (Exception ex)
            {
                //Console.WriteLine(ex.Message);
                test.Log(Status.Fail, "Search By TrackingId Test Failed for: " + ex.Message);
                Assert.Fail();
            }
        }




        //=========================================================================================================================
        public static object[] SearchBySearchTwoParmData()
        {
            object[] main = ExcelUtlis.SheetIntoObject(@"C:\Users\M3GMK00\source\repos\QandATest\QandATest\TestData\QandATestData.xlsx", "TwoParm");
            return main;
        }

        [Test, Order(2), Ignore("SearchBySearchTwoParmData")]
        //[Test, Order(2), TestCaseSource("SearchBySearchTwoParmData")]
        public void SearchByTwoParm(string keywords, string trackingIds)
        {
            try
            {
                string expectTitle = "Q&A - Y14 Dashboard";
                test = extent.CreateTest("Search By TwoParm ");
                SearchPage search = new SearchPage(driver);
                search.ClickOnAllQARadioBtn();
                test.Log(Status.Info, "Click On AllQARadio Button");

                search.EnterKeyword(keywords);
                test.Log(Status.Info, "Entered Keyword : " + keywords);

                search.EnterTrackingID(trackingIds);
                test.Log(Status.Info, "Entered Tracking ID : " + trackingIds);

                search.ClickOnSearchBtn();
                test.Log(Status.Info, "Click On Search Button");

                DashboardPage dashboard = new DashboardPage(driver, wait);

                string actualTitle = dashboard.WaitForLogOutPresentAndGetTitle();
                Assert.AreEqual(expectTitle, actualTitle, "Assertion on Create New Question");
                test.Log(Status.Info, "Actual Page Title is : " + actualTitle);

                //dashboard.ClickOnLogOut();
                search.ClickOnLogOutBtn();

                test.Log(Status.Info, "Successfully Logout from application");
                test.Log(Status.Pass, "End Search By TwoParm Test");
                SaveScreenShot("SearchByTwoParm");

            }
            catch (Exception ex)
            {
                //Console.WriteLine(ex.Message);
                test.Log(Status.Fail, "Search By TwoParmData Failed for: " + ex.Message);
                Assert.Fail();
            }
        }

        //===============================================================================================================================================================
        public static object[] SearchByParametersData()
        {
            object[] main = ExcelUtlis.SheetIntoObject(@"C:\Users\M3GMK00\source\repos\QandATest\QandATest\TestData\QandATestData.xlsx", "SearchByParm");
            return main;
        }

        [Test, Order(3), Ignore("Not running now")]
        //[Test, Order(3), TestCaseSource("SearchByParametersData")]
        public void SearchQandAquestion()
        {
            try
            {
                //ChromeOptions options = new ChromeOptions();
                //options.AddAdditionalCapability("useAutomationExtension", false);
                //IWebDriver driver = new ChromeDriver(options);

                test = extent.CreateTest("SearchByParametersTest");

                IWebDriver driver = new InternetExplorerDriver();
                driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(60);
                //driver.Navigate().GoToUrl(url);
                driver.Manage().Window.Maximize();   //driver.Manage().Window.FullScreen();
                System.Threading.Thread.Sleep(10000);

                //driver.FindElement(By.XPath("(//input[@id='searchFor'])[2]")).Click(); // "My (Questions I'm Involved in)" Radio Button-3 
                //Thread.Sleep(1000);
                //driver.FindElement(By.XPath("(//input[@id='searchFor'])[3]")).Click(); // "Q&As Requiring My Attention" Radio Button-2 
                //Thread.Sleep(1000);

                IWebElement allQAsRadioButton = driver.FindElement(By.XPath("(//input[@id='searchFor'])[1]"));
                allQAsRadioButton.Click();
                Thread.Sleep(1000);

                IWebElement keywordTextField = driver.FindElement(By.Id("keyword-search"));
                keywordTextField.SendKeys("POC");
                Thread.Sleep(1000);

                IWebElement trackingIDTextField = driver.FindElement(By.Id("tracking-id-search"));
                trackingIDTextField.SendKeys("Y140001469");
                System.Threading.Thread.Sleep(5000);

                IWebElement SearchButton = driver.FindElement(By.XPath("//button[contains(text(),'Search')]"));
                SearchButton.Click();
                Thread.Sleep(1000);

                IWebElement logoutButton = driver.FindElement(By.XPath("//a[contains(text(),'Logout')]"));
                logoutButton.Click();

                test.Log(Status.Pass, "End Search By Parameters Test");  //ISSUE

                driver.Close();
                driver.Quit();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                test.Log(Status.Fail, "Search By Parameters Test" + ex.Message);
                Assert.Fail();
            }

        }   

    }
}







/*
         [SetUp]
        public void SetUp()
        {
            string url = ConfigUtlis.GetValueFromConfig("url");
            driver = new FirefoxDriver();
            wait = new WebDriverWait(driver, TimeSpan.FromSeconds(60)); //Explicit Wait
            driver.Manage().Window.Maximize();
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30); // Implicit Wait
            driver.Url = url;
        }

        [TearDown]
        public void CloseBrowser()
        {
            driver.Quit();
        }

       [Test, Order(1)]
        public void FindByTrackingID()
        { 
            
            string track_ID = "Y140001469";
            string keywordsearch = "POC";

            IWebDriver driver = new InternetExplorerDriver();
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(60);
            //driver.Navigate().GoToUrl(url);
            driver.Manage().Window.Maximize();   //driver.Manage().Window.FullScreen();
            System.Threading.Thread.Sleep(10000);

            IWebElement allQAsRadioButton = driver.FindElement(By.XPath("(//input[@id='searchFor'])[1]"));
            allQAsRadioButton.Click();
            Thread.Sleep(1000);

            IWebElement keywordTextField = driver.FindElement(By.Id("keyword-search"));
            keywordTextField.SendKeys(keywordsearch);
            Thread.Sleep(1000);

            IWebElement trackingIDTextField = driver.FindElement(By.Id("tracking-id-search"));
            trackingIDTextField.SendKeys(track_ID);
            System.Threading.Thread.Sleep(5000);

            IWebElement SearchButton = driver.FindElement(By.XPath("//button[contains(text(),'Search')]"));
            SearchButton.Click();
            Thread.Sleep(1000);


            ReadOnlyCollection<IWebElement> rowEle = driver.FindElements(By.XPath("//table[@class='table table-bordered table-hover faq-table']/tbody/tr/td[1]"));
            int numberOfRows = rowEle.Count;

            for (int i = 1; i <= numberOfRows; i++)
            {
                IWebElement TrackingIDEle = driver.FindElement(By.XPath("//table[@class='table table-bordered table-hover faq-table']/tbody/tr/td["+ i + "]"));
                String Tracking_ID = TrackingIDEle.Text;

                Console.WriteLine(Tracking_ID);

                //if (Tracking_ID.Trim().Equals(track_ID))
                //{
                //    IWebElement searchEle = driver.FindElements(By.XPath("//table[@class='table table-bordered table-hover faq-table']/tbody/tr/td[" + i + "]"));
                //    searchEle.Click();
                //    break;
                //}
            }

        }
 */


/*
 Q&A Manager    :     @"https://itappst.frb.gov/fAq/index.html#/Y-14/Dashboard"
 Pauline POC1   :     @"https://itappst.frb.gov/faq/?testid=BOARD\POC1#/Y-14/Dashboard"
 Sam SME1       :     @"https://itappst.frb.gov/faq/?testid=BOARD\SME1#/Y-14/Dashboard"
 Riley Reviewer1:     @"https://itappst.frb.gov/fAq/?testid=BOARD\Reviewer1#/Y-14/Dashboard"
 Logan LReviewer1:    @"https://itappst.frb.gov/fAq/?testid=BOARD\LReviewer1#/Y-14/Dashboard" 
*/
