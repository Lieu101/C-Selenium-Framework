﻿using OpenQA.Selenium;
using System;
using System.Threading;


namespace QandA.Pages
{
    class SMEstagePage 
    {
        public IWebDriver driver;
        public SMEstagePage(IWebDriver driver)
        {
            this.driver = driver;
        }

        // Question Y140001515 was updated successfully.

        //================  SME Page Locators  Y140001515 ===========================================
        //1 Click on All Radio Button
        private By allQandARadioBtnLoc = By.XPath("(//input[@id='searchFor'])[1]");

        //2 Click On "More Option" Search DropDown arrow
        //private By moreFewerOptionLoc = By.XPath("//button[@id='more-less']/text()");
        private By moreFewerOptionLoc = By.XPath("//button[@id='more-less']");

        //3 Click On "Workflow Stage" DropDown arrow to Select Question Stages 
        private By workFlowStageLoc = By.Id("search-workflow-stage");
        private By workFlowSMEstageLoc = By.XPath("//select[@id='search-workflow-stage']/option[contains(@class, 'ng-binding ng-scope') and contains(@value, '2')]");// Only SME Stage
        //private By workflowStageLoc = By.XPath("//select[@id='search-workflow-stage']"); // for All stages

        //4 Enter "Sam SME1" in SME Text Box SendKeys
        private By smeNameLoc = By.XPath("//input[@id='search-sme']"); 

        //5 Click on Question Search Button
        private By searchBtnLoc = By.XPath("//button[contains(text(),'Search')]");

        //6 Click on 1st row or 3rd value of Question Value_Link from the Search Results Table
        private By questionLinkLoc = By.XPath("//table[@class='table table-bordered table-hover faq-table']/tbody/tr[1]/td[3]");
        private By trackingidNoLoc = By.XPath("//table[@class='table table-bordered table-hover faq-table']/tbody/tr[1]/td[1]");

        //7 Click on Send to Business Reviewer Button  
        private By businessReviewerButtonLoc = By.XPath("(//div//button[contains(@class, 'btn btn-primary') and contains(text(), 'Send to Business Reviewer')])[1]");

        //8 Missing criteria Message Box Close
        private By missingCriteriaDialogLoc = By.XPath("//pre[contains(@id, 'modelDialogContent') and contains(text(), 'Please enter an answer.')]");
        private By missingCriteriaCloseLoc = By.XPath("(//button[contains(@type, 'button') and contains(text(), 'Close')])[8]");

        //9 Click on Edit Answer Link text BOX
        private By editAnswerLinkLoc = By.XPath("//p[contains(@class, 'edit-modal-links')]/a[contains(text(), 'Edit Answer')]");

        //10 Type SME Answer in "Answer" text BOX
        private By enterAnswerLoc = By.XPath("//textarea[@id='EditableTextarea']");

        //11 Click on Answer "Submit" Button 
        private By answerSubmitBtnLoc = By.XPath("//*[@id='textbox-editable']/div/div/div[3]/button[2]");      

        //12 Click on "Add New Comment" Link text BOX
        private By addNewCommentLinkLoc = By.XPath("//p[contains(@class, 'edit-modal-links')]/a[contains(text(), 'Add New Comment')]");

        //13 Type on "Add New Comment" Link text BOX
        private By enterCommentLoc = By.XPath("//p[contains(@class, 'edit-modal-links')]/a[contains(text(), 'Add New Comment')]");

        //14 Click on Comment "Submit" Button
        private By commentSubmitBtnLoc = By.XPath("//*[@id='textbox-editable']/div/div/div[3]/button[2]");

        //15 Click on "Send to Business Reviewer" Button
        private By sendToBusinessReviewerBtnLoc = By.XPath("//*[@id='QuestionEditForm']/div[4]/div[2]/div[5]/div/div/div[2]/table/tbody/tr/td/div[2]/button");

        //16 Q&A Message : Question Y140001444 was updated successfully.
        private By QuestionupdatedsuccessfullyLoc = By.XPath("//pre[contains(@id, 'modelDialogContent') and contains(@tabindex, '0')]");
        private By CloseQAMessageLoc = By.XPath("(//button[contains(@class, 'btn btn-default') and contains(text(), 'Close')])[2]");

        //18 Click On "LogOut" Button
        private By logOutBtnLoc = By.XPath("//li/a[text()= 'Logout']");

        // Enter Tracking ID Y140001515 
        //private By trackingIDLoc = By.Id("tracking-id-search");
        //==================================================================================================
        //Genered method to CLICK using IJavaScriptExecutor
        public bool ClickElementWithJS(IWebElement element, int delay)
        {
            for (int i = 1; i < delay; i++)
            {
                try
                {
                    IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
                    js.ExecuteScript("arguments[0].click();", element);
                    return true;
                }
                catch (NoSuchElementException ex)
                {
                    Thread.Sleep(1000);
                }
            }
            return false;
        }

        public bool EnterInSendKeys(IWebElement element, string text, int delay)
        {
            for (int i = 1; i < delay; i++)
            {
                try
                {
                    element.SendKeys(text);
                    return true;
                }
                catch (NoSuchElementException ex)
                {
                    Thread.Sleep(1000);
                }
            }
            return false;
        }


        public void SelectFromDropDownList(string listItem)
        {
            //List<string> dropDownList = new List<string>();

            //ReadOnlyCollection<IWebElement> dropDownEle = driver.FindElements(By.Id("search-workflow-stage"));

            //foreach (IWebElement list in dropDownEle)
            //{
            //    dropDownList.Add(list.Text);
            //}

            //int rowCount = dropDownEle.Count;

            //for (int i = 1; i <= rowCount; i++)
            //{
            //    if (dropDownList == listItem)
            //    {
            //        Thread.Sleep(1000);
            //        dropDownEle.Click();
            //    }

            //}
        }



        //==================================================================================================
        // Click On LogOut Button
        public void ClickOnLogOutBtn()
        {
            IWebElement logOutEle = driver.FindElement(logOutBtnLoc);
            ClickElementWithJS(logOutEle, 10);
        }


        // ClickElement(IWebElement element, int delay)
        // Click On "More OR Less Option" Radio Button
        public void ClickOnMoreORLessOptionLocBtn()
        {
            IWebElement moreFewerOptionEle = driver.FindElement(moreFewerOptionLoc);
            ClickElementWithJS(moreFewerOptionEle, 10);
        }


        //1 Click on 'ALL Q&As' Radio Button
        public void ClickOnALLRadioBtn()
        {
            IWebElement allQandARadioBtnEle = driver.FindElement(allQandARadioBtnLoc);
            ClickElementWithJS(allQandARadioBtnEle, 10);
            //IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            //IWebElement allQandARadioBtnEle = driver.FindElement(allQandARadioBtnLoc);
            //Thread.Sleep(3000);
            //js.ExecuteScript("arguments[0].click();", allQandARadioBtnEle);
        }

        //2 Click On "More Option" Search DropDown arrow
        public void ClickOnmoreFewerOption()
        {
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            IWebElement moreFewerOptionEle = driver.FindElement(moreFewerOptionLoc);
            Thread.Sleep(3000);
            js.ExecuteScript("arguments[0].click();", moreFewerOptionEle);
        }

        //3 Click On "Workflow Stage" DropDown arrow to Select Question Stages 
        public void SelectWorkFlowSMEstage()
        {
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            IWebElement workflowSMEstageEle = driver.FindElement(workFlowSMEstageLoc);
            Thread.Sleep(1000);
            js.ExecuteScript("arguments[0].click();", workflowSMEstageEle);           
        }

        //4  Type "Sam SME1" in SME Text Box 
        public void TypeSMEName(string smeName)
        {
            IWebElement smeNameEle = driver.FindElement(smeNameLoc);
            smeNameEle.SendKeys(smeName);
        }

        //5 Click on Question Search Button
        public void ClickOnSearchBtn()
        {
            IWebElement smeNameEle = driver.FindElement(searchBtnLoc);
            ClickElementWithJS(smeNameEle, 10);
            //IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            //IWebElement smeNameEle = driver.FindElement(searchBtnLoc);
            //Thread.Sleep(1000);
            //js.ExecuteScript("arguments[0].click();", searchBtnLoc);
        }


        //6 Click on 1st row or 3rd value of Question Value_Link from the Search Results Table
        public void CleckOnQuestionLink()
        {
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            IWebElement questionLinEle = driver.FindElement(questionLinkLoc);
            string question = questionLinEle.Text;
            Thread.Sleep(1000);
            js.ExecuteScript("arguments[0].click();", questionLinkLoc);
            Console.WriteLine("The Question is: " + question);

            IWebElement trackingidNoEle = driver.FindElement(trackingidNoLoc);
            Console.WriteLine("The Tracking No is: " + trackingidNoEle.Text);
        }


        //7 Click on Send to Business Reviewer Button  
        public void ClickOnBusinessReviewerButton()
        {
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            IWebElement closeAlertEle = driver.FindElement(businessReviewerButtonLoc);
            js.ExecuteScript("arguments[0].click();", businessReviewerButtonLoc);
        }

        //8 Click on Close Button of "Missing criteria Message"
        public void CloseMissingCriteriaAlertMessage()
        {
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            IWebElement closeAlertEle = driver.FindElement(missingCriteriaCloseLoc);
            js.ExecuteScript("arguments[0].click();", closeAlertEle);
        }

        //9 Click on Edit Answer Link text BOX
        public void ClickOnEditAnswerLink()
        {
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            IWebElement editAnswerLinkEle = driver.FindElement(editAnswerLinkLoc);
            js.ExecuteScript("arguments[0].click();", editAnswerLinkEle);
        }

        //10 Type SME Answer into "Answer" text BOX
        public void TypeSMEAnswer(string smeAnswer)
        {
            IWebElement enterAnswerEle = driver.FindElement(enterAnswerLoc);
            enterAnswerEle.SendKeys(smeAnswer);
        }

        //11 Click on Answer "Submit" Button
        public void ClickOnAnswerSubmitBtn()
        {
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            IWebElement answerSubmitBtnEle = driver.FindElement(answerSubmitBtnLoc);
            //answerSubmitBtnEle.Click();
            js.ExecuteScript("arguments[0].click();", answerSubmitBtnEle);
        }


        //12 Click on "Add New Comment" Link text BOX
        public void ClickOnAddANewCommentLink()
        {
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            IWebElement addNewCommentLinkEle = driver.FindElement(addNewCommentLinkLoc);
            //addNewCommentLinkEle.Click();
            js.ExecuteScript("arguments[0].click();", addNewCommentLinkEle);
        }

        //13 Type SME Comment into "Comment" text BOX
        public void TypeSMEComment(string smeComment)
        {
            IWebElement enterCommentEle = driver.FindElement(enterCommentLoc);
            enterCommentEle.SendKeys(smeComment);
        }

        //14 Click on Answer "Submit" Button
        public void ClickOnCommentSubmitBtn()
        {
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            IWebElement commentSubmitBtnEle = driver.FindElement(commentSubmitBtnLoc);
            //answerSubmitBtnEle.Click();
            js.ExecuteScript("arguments[0].click();", commentSubmitBtnEle);
        }

        //15 Click on "Send To Business Reviewer Button" 
        public void ClickSendToBusinessReviewerBtn()
        {
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            IWebElement sendToBusinessReviewerBtnEle = driver.FindElement(sendToBusinessReviewerBtnLoc);
            //sendToBusinessReviewerBtnEle.Click();
            js.ExecuteScript("arguments[0].click();", sendToBusinessReviewerBtnEle);
        }

        //16 Store "Q&A Message : Question Y140001444 was updated successfully."
        public void QuestionUpdatedMessage()
        {
            IWebElement QuestionupdatedsuccessfullyEle = driver.FindElement(QuestionupdatedsuccessfullyLoc);
            string message = QuestionupdatedsuccessfullyEle.Text;
            Console.WriteLine("SME Stage Update Confirmation Message is : " + message);
            Console.WriteLine("SME Stage Update Tracking ID No : " + message.Substring(12, 20));
        }

        //17 Click to Close Q&A Message : Question Y140001444 was updated successfully.
        public void CloseQAMessageBox()
        {
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            IWebElement CloseQAMessageEle = driver.FindElement(CloseQAMessageLoc);
            js.ExecuteScript("arguments[0].click();", CloseQAMessageEle);
        }

        //18 Click On LogOut Button
        public void ClickOnLogOutButton()
        {
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            IWebElement logOutBtnEle = driver.FindElement(logOutBtnLoc);
            js.ExecuteScript("arguments[0].click();", logOutBtnEle);
        }

        /*
        //==============> Step-6  Get the tracking_id from search result an store in a variable "Tracking_ID"
        private By storeTrackingIdLoc = By.XPath("//table[@class='table table-bordered table-hover faq-table']/tbody/tr[1]/td[1]");
        string Tracking_ID = storeTrackingIdLoc.Text;
        // "Y-14: " + Tracking_ID + " - Q&A is awaiting approval of SME"; 
        string expectedText = "Y-14: " + Tracking_ID + " - Q&A is awaiting approval of SME"; // 6,15

        // Print the Tracking_ID
        Console.WriteLine("The Tracking ID is : " + Tracking_ID);

            //==============> Step-7  Click on 1st row's 3rd value of column name Question "Value_Link" from the Search Results Table
            IWebElement questionLinkLoc = By.XPath("//table[@class='table table-bordered table-hover faq-table']/tbody/tr[1]/td[3]");
        questionLinkLoc.Click();

            //==============> Step-8
            private By smePageLoc = driver.FindElement(By.XPath("//span[@class= 'h1 ng-binding']"));
            string actualText = smePageLoc.Text; //Y-14: Y140000050 - Q&A is awaiting approval of SME

            if (expectedText == actualText)
            {
                Console.WriteLine(actualText);
            }
            */

            // Y140001444 
            //Pauline POC1 

    }
}
