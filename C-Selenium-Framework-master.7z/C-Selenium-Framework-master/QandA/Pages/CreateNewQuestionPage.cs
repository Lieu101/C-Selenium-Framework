﻿using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using System;
using System.Threading;

namespace QandA.Pages
{
    class CreateNewQuestionPage 
    {
        public IWebDriver driver;

        // Create a constractor for IWebDriver
        public CreateNewQuestionPage(IWebDriver driver)
        {
            this.driver = driver;
        }
        //================ Create New Question Page Locators ===========================================

        //private By addNewQuestionLoc = By.XPath("//h2/a"); // 
        private By addNewQuestionLoc = By.LinkText("Add New Question");

        private By dateAndTimeQuestionReceived = By.Id("DateQuestionReceived");

        private By dateAndTimeLoc = By.XPath("(//span[@class='glyphicon glyphicon-calendar'])[2]");

        private By toDayLoc = By.XPath("(//th[@class='today'])[18]");

        //===========================================================================================================================
        //      Contacts Submitter (Respondent)
        private By primarySubmitterAddLinkLoc = By.XPath("(//a[text()='add'])[3]");

        private By frimNameLoc = By.XPath("//*[@id='SubmitterPrimaryFirmId']/option[9]");
        //private By frimNameLoc = By.Id("SubmitterPrimaryFirmId");

        private By firstNameLoc = By.XPath("//*[@id='SubmitterPrimaryGivenName']");
        //private By firstNameLoc = By.Id("SubmitterPrimaryGivenNamee");

        private By lastNameLoc = By.XPath("//*[@id='SubmitterPrimarySurName']");
        //private By lastNameLoc = By.Id("SubmitterPrimaryEmail");

        private By emailAddressLoc = By.XPath("//*[@id='SubmitterPrimaryEmail']");
        //private By emailAddressLoc = By.Id("SubmitterPrimaryEmail");

        private By phoneNoLoc = By.XPath("//*[@id='SubmitterPrimaryPhone']");
        //private By phoneNoLoc = By.XPath("//*[@id='SubmitterPrimaryPhone']");

        private By updateBtnLoc = By.XPath("//*[@id='PrimarySubmitterForm']/div[2]/button[2]");
        //private By updateBtnLoc = By.Id("SubmitterPrimaryPhone"); 

        private By closeRespondentBtnLoc = By.XPath("//*[@id='PrimarySubmitterForm']/div[2]/button[1]");


        //===========================================================================================================================
        //       Original Question Text Box  
        private By originalQuestionLoc = By.XPath("//textarea[@id='OriginalQuestion']");
        //private By originalQuestionLoc = By.Id("OriginalQuestion]");

        //------------------- Answer Text Box 
        private By answerLoc = By.XPath("//textarea[@id='Answer']");
        //private By answerLoc = By.Id("Answer");

        //------------------- Comments Text Box 
        private By commentsLoc = By.XPath("//textarea[@id='Comments']");
        //private By commentsLoc = By.Id("Comments");

        //===========================================================================================================================

        //      Confidentiality Request Justification  Text Box 
        private By confidentialityRequestJustificationLoc = By.XPath("//textarea[@id='Request']");
        //private By confidentialityRequestJustificationLoc = By.Id("Request]");


        //      Confidentiality Request Justification  Upload Attachment Link 
        private By uploadAttachmentLoc = By.XPath("//a[contains(text(), 'Upload Attachment']");
        //private By uploadAttachmentLoc = By.LinkText("Upload Attachment");

        //===============================================================================================================================
        //   Details 
        //private By selectSeriesLoc = By.XPath("//select[@id='Series']");
        private By selectSeriesLoc = By.Id("Series");

        //private By scheduleLoc = By.XPath("//select[@id='Schedule']");
        private By scheduleLoc = By.Id("Schedule");

        //private By subScheduleLoc = By.XPath("//select[@id='SubSchedule']");
        private By subScheduleLoc = By.Id("SubSchedule");

        private By categoryLoc = By.XPath("//select[@id='Category']");
        //private By categoryLoc = By.Id("Category");

        private By impactsUpcomingDataCheckBoxLoc = By.XPath("//input[@id='ImpactsUpcomingData']");
        //private By impactsUpcomingDataCheckBoxLoc= By.Id("ImpactsUpcomingData");

        private By impactsYearDatatLoc = By.Id("ImpactsUpcomingDate");

        //^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
        // Select From drop down list

        //private By asOfDateCheckBoxLoc = By.XPath("//div[@id='as-of-date2']//input[@value= '']");
        private By asOfDateCheckBoxLoc = By.XPath("//*[@id='as-of-date2']/label/input");
        //private By asOfDateCheckBoxLoc = By.Id("as-of-date");
        //private By asOfDateCheckBoxLoc = By.Id("as-of-date2");
        //private By asOfDateCheckBoxLoc = By. CssSelector("#as-of-date");
        //private By asOfDateCheckBoxLoc = By.XPath("//*[@id='as-of-date']");

        //^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^



        private By confidentialityRequestedLoc = By.XPath("//select[@id='FirmSpecific']");
        //private By confidentialityRequestedLoc = By.XPath("//select[@id='FirmSpecific']//option");
        //private By confidentialityRequestedLoc = By.Id("FirmSpecific");

        //private By confidentialityRequestedLoc = By.XPath("//div[@id='Request']//select[@id='FirmSpecific']//option[contains(text(), 'Yes' )]");


        private By sendtoSMEButonLoc = By.XPath("(//button[@class='btn btn-primary'])[1]");

        //===============================================================================================================================

        // Withdraw from Workflow Drop Down  
        private By withdrawFromWorkflowLoc = By.XPath("//select[@id='CloseReason']");
        //private By withdrawFromWorkflowLoc = By.Id("CloseReason");

        private By withdrawButtonLoc = By.XPath("(//button[@class='btn btn-default'])[2]");

        //===============================================================================================================================

        // * Read Missing criteria Message Box 
        private By readMissingCriteriaMessageLoc = By.XPath("//pre[contains(@id, 'modelDialogContent') and contains(@class, 'wrap-word multiline ng-binding')]");

        // * Missing criteria Message Box Close
        private By missingCriteriaCloseLoc = By.XPath("(//button[contains(@class, 'btn btn-default') and contains(text(), 'Close')])[8]");


        //*****************************************************************************************************************************************************
        //================ Create New Question Page Methods ===========================================
        public void BrowserZooM()
        {
            //IWebDriver driver;
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            string zoomInJS = "document.body.style.zoom='100%'";
            js.ExecuteScript(zoomInJS);
        }

        public void ReadCriteriaAlertMessage()
        {
            //IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            IWebElement readMessageEle = driver.FindElement(readMissingCriteriaMessageLoc);
             string message = readMessageEle.Text;
            Console.WriteLine("Missing Criteria Alert Message is : " + message);
        }

        public void CloseMissingCriteriaAlertMessage()
        {
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            IWebElement closeAlertEle = driver.FindElement(missingCriteriaCloseLoc);
            closeAlertEle.Click();
            js.ExecuteScript("arguments[0].click();", closeAlertEle);
        }

        public void AlertMessage()
        {
            IAlert alertBox = driver.SwitchTo().Alert();
            String alertText = alertBox.Text;
            Console.WriteLine(alertText);
            alertBox.Dismiss();
            //IWebElement missingCriteriaEle = driver.FindElement(missingCriteriaMessageLoc);
            //Console.WriteLine(missingCriteriaMessageLoc);
            //driver.SwitchTo().Alert().Accept();

        }


        //* Click on add a New Question Link
        public void ClickNewQuestion()
        {
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            IWebElement newQuestionEle = driver.FindElement(By.XPath("//h2/a"));
            js.ExecuteScript("arguments[0].click();", newQuestionEle);
            Thread.Sleep(1000);
        }



        //* Click Today
        public void ClickOnToDay()
        {
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            IWebElement toDayEle = driver.FindElement(toDayLoc);
            Thread.Sleep(1000);
            js.ExecuteScript("arguments[0].click();", toDayEle);
        }


        //* Click on primary Submitter Add Link
        public void ClickprimarySubmitterAddLink()
        {
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            IWebElement primarySubmitterEle = driver.FindElement(primarySubmitterAddLinkLoc);
            Thread.Sleep(3000);
            js.ExecuteScript("arguments[0].click();", primarySubmitterEle);
            //primarySubmitterAddLinkEle.Click();
        }

        //-----------------------------------------------------------------------------------------------------------------------------------
        //* Select FirmName from DropDown List
        public void SelectFirmNameDropDown(string frimNames)
        {
            IWebElement firmNameEle = driver.FindElement(frimNameLoc);
            Thread.Sleep(1000);
            //SelectElement select = new SelectElement(firmNameEle);
            //select.SelectByText(frimNames);
            firmNameEle.Click();
        }


        //* Type First Name 
        public void TypeFirstName(string firstNames)
        {
            IWebElement firstNameEle = driver.FindElement(firstNameLoc);
            Thread.Sleep(1000);
            firstNameEle.SendKeys(firstNames);
        }

        //* Type Last Name 
        public void TypelastName(string lastNames)
        {
            IWebElement lastNameEle = driver.FindElement(lastNameLoc);
            Thread.Sleep(1000);
            lastNameEle.SendKeys(lastNames);
        }


        //* Type email Address 
        public void TypeemailAddress(string emails)
        {
            IWebElement emailAddressEle = driver.FindElement(emailAddressLoc);
            Thread.Sleep(1000);
            emailAddressEle.SendKeys(emails);
        }

        //* Type  phone Number 
        public void TypePhoneNo(string phones)
        {
            IWebElement phoneNoEle = driver.FindElement(phoneNoLoc);
            Thread.Sleep(1000);
            phoneNoEle.SendKeys(phones);
        }

        //* Click on Update Button
        public void ClickOnUpdateBtn()
        {
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            IWebElement updateBtnEle = driver.FindElement(updateBtnLoc);
            Thread.Sleep(1000);
            //updateBtnEle.Click();
            js.ExecuteScript("arguments[0].click();", updateBtnEle);
        }


        //* Click on Primary Submitter (Respondent) Close Button
        public void ClickcloseRespondentBtn()
        {
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            IWebElement closeRespondentBtnEle = driver.FindElement(closeRespondentBtnLoc);
            Thread.Sleep(3000);
            //closeRespondentBtnEle.Click();
            js.ExecuteScript("arguments[0].click();", closeRespondentBtnEle);
        }
        //-----------------------------------------------------------------------------------------------------------------------------------
        //* Type  Original Question on Text Field 
        public void TypeOriginalQuestion(string originalQuestions)
        {
            IWebElement originalQuestionEle = driver.FindElement(originalQuestionLoc);
            Thread.Sleep(1000);
            originalQuestionEle.SendKeys(originalQuestions);
        }

        //* Type  Answer on Text Field 
        public void TypeAnswer(string answers)
        {
            IWebElement answerTextBoxEle = driver.FindElement(answerLoc);
            Thread.Sleep(1000);
            answerTextBoxEle.SendKeys(answers);
        }

        //* Type  Comments on Text Field 
        public void TypeComments(string comments)
        {
            IWebElement answerEle = driver.FindElement(commentsLoc);
            Thread.Sleep(1000);
            answerEle.SendKeys(comments);
        }

        //-----------------------------------------------------------------------------------------------------------------------------------
        //* Select Program/ Series from Dropdown List
        public void SelectSeriesFromDropDown(string selectSeries)
        {
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            IWebElement selectSeriesEle = driver.FindElement(selectSeriesLoc);
            SelectElement select = new SelectElement(selectSeriesEle);
            select.SelectByText(selectSeries);
            Thread.Sleep(1000);
            //selectSeriesEle.Click();

            js.ExecuteScript("arguments[0].click();", selectSeriesEle);
        }


        //* Select Schedule from Dropdown List
        public void SelectScheduleFromDropDown(string schedule)
        {
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            IWebElement scheduleEle = driver.FindElement(scheduleLoc);
            SelectElement select = new SelectElement(scheduleEle);
            select.SelectByText(schedule);
            Thread.Sleep(1000);
            //scheduleEle.Click();
            js.ExecuteScript("arguments[0].click();", scheduleEle);
        }

        //* Select Sub Schedule from Dropdown List
        public void SelectSubScheduleFromDropDown(string subSchedule)
        {
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            IWebElement subScheduleEle = driver.FindElement(subScheduleLoc);
            SelectElement select = new SelectElement(subScheduleEle);
            select.SelectByText(subSchedule);
            Thread.Sleep(1000);
            //subScheduleEle.Click();
            js.ExecuteScript("arguments[0].click();", subScheduleEle);
        }

        //* Select category from Dropdown List
        public void SelectcategoryFromDropDown(string category)
        {
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            IWebElement categoryEle = driver.FindElement(categoryLoc);
            SelectElement select = new SelectElement(categoryEle);
            select.SelectByText(category);
            Thread.Sleep(1000);
            //categoryEle.Click();
            js.ExecuteScript("arguments[0].click();", categoryEle);
        }

        //* Click On Impacts upcoming data submission Check Box
        public void ClickOnImpactCheckBox()
        {
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            IWebElement impactsEle = driver.FindElement(impactsUpcomingDataCheckBoxLoc);
            Thread.Sleep(1000);
            //impactsEle.Click();
            js.ExecuteScript("arguments[0].click();", impactsEle);
        }

        //* Select Impacts upcoming data submission 'Year Quarter 2019 Q4' from Drop Down List
        public void SelectImpactsYearDropDown(string impacts)
        {
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            IWebElement impactsYearEle = driver.FindElement(impactsYearDatatLoc);
            SelectElement select = new SelectElement(impactsYearEle);
            select.SelectByText(impacts);
            Thread.Sleep(1000);
            //impactsUpcomingDataSelectEle.Click();
            js.ExecuteScript("arguments[0].click();", impactsYearEle);
        }

        public void SelectAsOfDateCheckBoxFromCheckBox(string asOfDates)
        {
            string dt  = asOfDates;
            string XPathName = "//input[contains(@name, 'AsOfDates') and contains(@value, '" + dt + "')]";
            IJavaScriptExecutor js1 = (IJavaScriptExecutor)driver;
            IWebElement sOfDateCheckBoxLoc = driver.FindElement(By.XPath(XPathName));
            Thread.Sleep(1000);
            //SelectElement select = new SelectElement(sOfDateCheckBoxLoc);
            //select.SelectByText(asOfDates);
            js1.ExecuteScript("arguments[0].click();", sOfDateCheckBoxLoc);
        }

        /*            //string dt = "20181231";
        //string XPathName = "//input[contains(@name, 'AsOfDates') and contains(@value, '" + dt + "')]";
        //IJavaScriptExecutor js1 = (IJavaScriptExecutor)driver;
        //IWebElement sOfDateCheckBoxLoc = driver.FindElement(By.XPath(XPathName));
        //Thread.Sleep(7000);
        ////SelectElement select1 = new SelectElement(sOfDateCheckBoxLoc);
        ////select.SelectByText("20191231");
        //js1.ExecuteScript("arguments[0].click();", sOfDateCheckBoxLoc);

        //IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
        //IWebElement asOfDatesEle = driver.FindElement(asOfDateCheckBoxLoc);
        //SelectElement select = new SelectElement(asOfDatesEle);
        //select.SelectByValue(asOfDates);
        //Thread.Sleep(5000);
        //asOfDateCheckBoxEle.Click();
        //js.ExecuteScript("arguments[0].click();", asOfDatesEle);


        //IWebElement element = driver.FindElement(By.XPath("//Select"));
        //You can locate the element by using the ID / Name as well IList
        //AllDropDownList = asOfDatesEle.FindElements(By.XPath("//option"));
        //int DpListCount = AllDropDownList.Count;
        //for (int i = 0; i < DpListCount; i++)
        //{
        //    if (AllDropDownList[i].Text == "Coffee")
        //    {
        ////        AllDropDownList[i].Click();
        ////    }
        ////}
        //*/

        public void ClickConfidentiality()
        {
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            IWebElement confidentiality =  driver.FindElement(By.XPath("//*[@id='FirmSpecific']"));
            Thread.Sleep(1000);
            js.ExecuteScript("arguments[0].click();", confidentiality);
            //confidentiality.Click();
        }

        public void SendYes()
        {
            driver.FindElement(By.XPath("//select[@id='FirmSpecific']")).Click();
            IWebElement yesNo1 = driver.FindElement(By.XPath("//option[text()= 'Yes']"));
            Thread.Sleep(1000);
            yesNo1.SendKeys("Yes");
            //yesNo1.Click();

            
        }

        public void SelectConfidentialityRequested(string confidentialityRequesteds)
         {

            //string YesOrNo = confidentialityRequesteds;
            //string XPathYesNo = "//option[contains(@class, 'ng-binding ng-scope') and contains(@value, '" + YesOrNo + "')]";
            //IWebElement justificationLoc = driver.FindElement(By.XPath(XPathYesNo));
            //Thread.Sleep(1000);
            //justificationLoc.SendKeys("Yes");



            Actions actions = new Actions(driver);
            string YesOrNo = confidentialityRequesteds;
            string XPathYesNo = "//option[contains(@class, 'ng-binding ng-scope') and contains(@value, '" + YesOrNo + "')]";
            IWebElement justificationLoc = driver.FindElement(By.XPath(XPathYesNo));
            Thread.Sleep(1000);
            justificationLoc.Submit();
            //justificationLoc.Click();
            //actions.DoubleClick(justificationLoc).Perform();
            //actions.DoubleClick(justificationLoc).Build().Perform();

            //actions.MoveByOffset(300, 34).Click().Build().Perform();    //For X, Y Coordinator



            //IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            //IWebElement confidentialityEle = driver.FindElement(confidentialityRequestedLoc);
            //SelectElement select = new SelectElement(confidentialityEle);
            //select.SelectByText(confidentialityRequesteds);
            //Thread.Sleep(3000);
            //confidentialityEle.Click();
            //js.ExecuteScript("arguments[0].click();", confidentialityEle);
            //Thread.Sleep(3000);
            //Console.WriteLine("Click on Yes :" + js.ExecuteScript("arguments[0].click();", confidentialityEle));


        }


        public void YesORNo(string confidentialityRequesteds)
        {
            SelectElement yesORNo = new SelectElement(driver.FindElement(confidentialityRequestedLoc));
            yesORNo.SelectByValue(confidentialityRequesteds);
            //yesORNo.Click();

            //ReadOnlyCollection<IWebElement> rowEle = driver.FindElements(By.Id("FirmSpecific"));
            //foreach (IWebElement date in rowEle)
            //{
            //    yesOrNo.Add(date.Text);
            //}
        }
        

        //public void SelectConfidentialityRequested(string confidentialityRequesteds)
        //{
        //    IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
        //    IWebElement confidentialityEle = driver.FindElement(confidentialityRequestedLoc);
        //    SelectElement select = new SelectElement(confidentialityEle);
        //    select.SelectByText(confidentialityRequesteds);
        //    Thread.Sleep(3000);
        //    //confidentialityEle. Click();
        //    //js.ExecuteScript("arguments[0].click();", confidentialityEle);
        //    Thread.Sleep(3000);
        //}


        public void JustClickRequested()
        {
            //IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            IWebElement confidentialityEle = driver.FindElement(confidentialityRequestedLoc);
            Thread.Sleep(3000);
            confidentialityEle.Click();
            //js.ExecuteScript("arguments[0].click();", confidentialityEle);
            Thread.Sleep(3000);
            OpenQA.Selenium.Interactions.Actions action = new OpenQA.Selenium.Interactions.Actions(driver);
            action.MoveToElement(confidentialityEle).Click(confidentialityEle).Build().Perform();
            // action.Click();

        }

        //* Type  confidentiality Request Justification on Text Field 
        public void TypeConfidentialityRequestJustification(string confidentiality)
        {
            IWebElement confidentialityEle = driver.FindElement(confidentialityRequestJustificationLoc);
            Thread.Sleep(3000);
            confidentialityEle.SendKeys(confidentiality);
        }


        //* Click On Upload Attachment Link
        public void ClickOnUploadAttachment()
        {
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            IWebElement uploadAttachmentEle = driver.FindElement(uploadAttachmentLoc);
            Thread.Sleep(3000);
            //uploadAttachmentEle.Click();
            js.ExecuteScript("arguments[0].click();", uploadAttachmentEle);

            //@"C:\Users\M3GMK00\source\repos\UnitTestProject_01\POC_Attached\POC1.xlsx"
        }


        public void ClickOnSendToSME_ButtonLoc()
        {
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            IWebElement sendToSMEButonEle = driver.FindElement(sendtoSMEButonLoc);
            Thread.Sleep(5000);
            //sendToSMEButonEle.Click();
            js.ExecuteScript("arguments[0].click();", sendToSMEButonEle);
        }

        public void GetTrackingID()
        {
            //IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            IWebElement getTrackingEle = driver.FindElement(readMissingCriteriaMessageLoc);
            string trackingID = getTrackingEle.Text.Substring(12, 10);
            //string trackingID = message.Substring(12, message.LastIndexOf("was"));
            //string trackingID = message.Substring(12, 10);
            Console.WriteLine("New Question Tracking ID is : " + trackingID);
        }



    }
}
