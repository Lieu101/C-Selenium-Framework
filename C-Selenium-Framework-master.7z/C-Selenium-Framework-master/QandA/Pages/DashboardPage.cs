﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System.Threading;

namespace QandA.Pages
{
    class DashboardPage
    {
        //private By logOutLoc = By.LinkText("Logout");
        private By logOutLoc = By.XPath("//*[@id='navbar']/ul[2]/li[3]/a");

        private IWebDriver driver;
        private WebDriverWait wait;

        public DashboardPage(IWebDriver driver, WebDriverWait wait)
        {
            this.driver = driver;
            this.wait = wait;
        }

        //public string WaitForIsElementPresent(IWebDriver driver, WebDriverWait wait, string elementName)
        //{
        //    wait.Until(ExpectedConditions.PresenceOfAllElementsLocatedBy(logOutLoc));
        //    string title = driver.Title;
        //    return title;
        //}


        public string WaitForLogOutPresentAndGetTitle()
        {
            wait.Until(ExpectedConditions.PresenceOfAllElementsLocatedBy(logOutLoc));
            string title = driver.Title;
            return title;
        }

        //public void ClickOnLogOut()
        //{
        //    driver.FindElement(logOutLoc).Click();
        //}

        // Modified make wait if didnt find element 
        public void ClickOnLogOut()
        {
            IWebElement logOutEle = driver.FindElement(logOutLoc);
            //driver.FindElement(logOutLoc).Click();
            ClickElementWithJS(logOutEle, 10);
        }

        public bool ClickElementWithJS(IWebElement element, int delay)
        {
            for (int i = 1; i < delay; i++)
            {
                try
                {
                    IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
                    js.ExecuteScript("arguments[0].click();", element);
                    return true;
                }
                catch (NoSuchElementException ex)
                {
                    Thread.Sleep(1000);
                }
            }
            return false;
        }


    }
}
