﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PageObjects
{
    class SearchPage
    {
        public IWebDriver driver;
        public SearchPage(IWebDriver driver)
        {
            this.driver = driver;
        }

        private By myTitle = By.TagName("title");

        //================ Find Q&As ===========================================
        //Radio Buttons
        //private By allQandARadioBtnLoc = By.XPath("(//input[@id='searchFor'])[1]");
        private By allQandARadioBtnLoc = By.XPath("//input[@value='0']");

        private By logOutLoc = By.XPath("//*[@id='navbar']/ul[2]/li[3]/a");

        private By myRadioBtnLoc = By.XPath("(//input[@id='searchFor'])[2]");
        private By qAsRequiringRadioBtnLoc = By.XPath("(//input[@id='searchFor'])[3]");
        //=====================================================================
        private By moreFewerOptionLoc = By.XPath("//button[@id='more-less']/text()");
        private By fewerOptionLoc = By.XPath("//button[@id='more-less']/text()");


        private By keywordTextLoc = By.Id("keyword-search");
        private By trackingIDLoc = By.Id("tracking-id-search");


        private By workflowStageLoc = By.XPath("//select[@id='search-workflow-stage']"); // ALL 6 work flow Stages
        private By workflowALLLoc = By.XPath("//select[@id='search-workflow-stage']/option[text() = 'All']"); // Only "ALL" work flow Stage
        private By workflowPOCResponceLoc = By.XPath("//select[@id='search-workflow-stage']/option[contains(@class, 'ng-binding ng-scope') and contains(@value, '1')]"); // Only POC Responce
        private By workflowSMEResponceLoc = By.XPath("//select[@id='search-workflow-stage']/option[contains(@class, 'ng-binding ng-scope') and contains(@value, '2')]"); // Only SME Responce
        private By workflowBusinessReviewerLoc = By.XPath("//select[@id='search-workflow-stage']/option[contains(@class, 'ng-binding ng-scope') and contains(@value, '3')]"); // Only Business Reviewer
        private By workflowLegalReviewerLoc = By.XPath("//select[@id='search-workflow-stage']/option[contains(@class, 'ng-binding ng-scope') and contains(@value, '4')]"); // Only Legal Reviewer
        private By workflowClosedLoc = By.XPath("//select[@id='search-workflow-stage']/option[contains(@class, 'ng-binding ng-scope') and contains(@value, '5')]"); // Only Closed


        private By farmNameRespondentLoc = By.XPath("//select[@id='search-firm-name']");
        private By statusLoc = By.XPath("//select[@id='search-status']");

        private By smeLoc = By.XPath("//input[@id='search-sme']");
        private By businessReviewerLoc = By.XPath("//input[@id='search-reviewer']");
        private By legalReviewerLoc = By.XPath("//input[@id='search-lreviewer']");

        private By seriesLoc = By.XPath("//select[@id='SearchSeries']");
        private By scheduleLoc = By.XPath("//select[@id='search-schedule']");
        private By subScheduleLoc = By.XPath("//select[@id='search-sub-schedule']");

        private By categoryLoc = By.XPath("//select[@id='SearchSeries']");
        private By publishedFromDateLoc = By.XPath("//input[@id='start-date']");
        private By publishedToDateLoc = By.XPath("//input[@id='end-date']");

        private By instructionsClarificationLoc = By.XPath("//input[@id='search-instructions']");

        private By confidentialityRequestedLoc = By.XPath("//select[@id='confidentiality-r']");
        private By confidentialityDecisionLoc = By.XPath("//select[@id='confidentiality-d']");
        
        // Search Button
        private By searchBtnLoc = By.XPath("//button[contains(text(),'Search')]");
        
        // Results: Q&As Requiring My Attention showing
        private By trackingRowValueLoc = By.XPath("//table[@class='table table-bordered table-hover faq-table']/tbody/tr/td[1]");
        private By searchResultQuestionRowValueLoc = By.XPath("//table[@class='table table-bordered table-hover faq-table']/tbody/tr/td[3]");



        //private IWebDriver driver;
        //private SearchPage(IWebDriver driver)
        //{
        //    this.driver = driver;
        //}

        /*
       [FindsBy(How = How.Id, Using = "Passwd")]
       public IWebElement Password { get; set; }

       WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
       wait.Until(ExpectedConditions.ElementIsVisible(By.Id("Passwd")));
       */

        //private By trackingIDLoc = By.Id("tracking-id-search");
        //wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.Id("tracking-id-search"))));

        
       public void EnterText1(IWebElement element, string text)
        {
            try
            {
                element.SendKeys(text);
            }
            catch (NoSuchElementException ex)
            {
                Thread.Sleep(5000);
                element.SendKeys(text);
            }
        }




        //Method to CLICK 
        public bool ClickElement(IWebElement element, int delay)
        {
            for (int i = 1; i < delay; i++)
            {
               try
                {
                    element.Click();
                    return true;
                }

                catch (NoSuchElementException ex)
                {
                    Thread.Sleep(5000);
                }
            }
            return false;
        }




        //Method to CLICK using IJavaScriptExecutor
        public bool ClickElementWithJS(IWebElement element, int delay)
        {
            for (int i = 1; i < delay; i++)
            {
                try
                {
                    IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
                    js.ExecuteScript("arguments[0].click();", element);
                    return true;
                }
                catch (NoSuchElementException ex)
                {
                    Thread.Sleep(5000);
                }
            }
            return false;
        }

        //Genered method to Enter data 
        public void EnterText(IWebElement element, string text)
        {
            try
            {
                element.SendKeys(text);
            }
            catch (NoSuchElementException ex)
            {
                Thread.Sleep(5000);
                element.SendKeys(text);
            }
        }


        public bool EnterInSendKeys(IWebElement element, string text, int delay)
        {
            for (int i = 1; i < delay; i++)
            {
                try
                {
                    element.SendKeys(text);
                    return true;
                }

                catch (NoSuchElementException ex)
                {
                    Console.WriteLine(ex.Message);
                    Thread.Sleep(5000);
                }
            }
            return false;
        }


        public void selectElement(IWebElement enterEle, string text)
        {
            try
            {
                enterEle.SendKeys(text);
            }
            catch (NoSuchElementException ex)
            {
                Thread.Sleep(3000);
                enterEle.SendKeys(text);
            }
        }



        //================================================================================================
        // Click On All Q&A Radio Button
        public void ClickOnAllQARadioBtn()
        {
            IWebElement allQARadioBtnEle = driver.FindElement(allQandARadioBtnLoc);
            ClickElementWithJS(allQARadioBtnEle, 10);
        }
        //public void ClickOnAllQARadioBtn()
        //{
        //    IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
        //    IWebElement allQARadioBtnEle = driver.FindElement(allQandARadioBtnLoc);
        //    Thread.Sleep(1000);
        //    js.ExecuteScript("arguments[0].click();", allQARadioBtnEle);
        //}

        // Click On LogOut Button
        public void ClickOnLogOutBtn()
        {
            IWebElement logOutEle = driver.FindElement(logOutLoc);
            ClickElementWithJS(logOutEle, 10);
        }


        // ClickElement(IWebElement element, int delay)
        // Click On "More OR Less Option" Radio Button
        public void ClickOnMoreORLessOptionLocBtn()
        {
            IWebElement moreFewerOptionEle = driver.FindElement(moreFewerOptionLoc);
            //wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.id("pagelet_bluebar"))));
            ClickElementWithJS(moreFewerOptionEle, 10);
        }

        // Type keyword in Text Box
        public void EnterKeyword(string keywords)
        {
            IWebElement keywordTexEle = driver.FindElement(keywordTextLoc);
            //EnterText(keywordTexEle, keywords);  //keywordTexEle.SendKeys(keyword);
            EnterInSendKeys(keywordTexEle, keywords, 10);
        }

        // Type  Tracking ID Text Box
        public void EnterTrackingID(string trackingIds)
        {
            IWebElement trackingIdEle = driver.FindElement(trackingIDLoc);
            EnterInSendKeys(trackingIdEle, trackingIds, 10);
        }

        //public void EnterTrackingID(string trackingIds)
        //{
        //    IWebElement trackingIdEle = driver.FindElement(trackingIDLoc);
        //    WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
        //    wait.Until(ExpectedConditions.PresenceOfAllElementsLocatedBy(trackingIDLoc));
        //    EnterInSendKeys(trackingIdEle, trackingIds, 10);
        //}


        // Type on SEM text Box
        public void EnterSME(string sme)
        {
            IWebElement trackingIdEle = driver.FindElement(smeLoc);
            EnterInSendKeys(trackingIdEle, sme, 10);
            //trackingIdEle.SendKeys(sme);
            //Thread.Sleep(1000);
        }



        

        //* Click On Search Button
        public void ClickOnSearchBtn()
        {
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            IWebElement searchBtnEle = driver.FindElement(searchBtnLoc);
            ClickElementWithJS(searchBtnEle, 15);
            Thread.Sleep(10000);

            //searchBtnEle.Click();
            //js.ExecuteScript("arguments[0].click();", searchBtnEle);
            //Thread.Sleep(6000);
        }


        // Click On Search Results 3rd Column "Question" value link no Parameter
        public void ClickOnQuestionLink()
        {
            IWebElement ClickQuestionEle = driver.FindElement(searchResultQuestionRowValueLoc);
            ClickElementWithJS(ClickQuestionEle, 10);
            //Thread.Sleep(3000);
            //ClickQuestionEle.Click();
            //Thread.Sleep(1000);
        }

        // Verification of Search Results 
        public void VerificationOfSearchResults(string trackingIds)
        {
            IWebElement trackingRowValueEle = driver.FindElement(trackingRowValueLoc);
            Thread.Sleep(3000);
            string actualTrackingID = trackingRowValueEle.Text;
            Thread.Sleep(1000);
            if(trackingIds == actualTrackingID)
            {
                Console.WriteLine("Search Result Matched test is Passed");
            }
        }

        // Click On Search Results 3rd Column "Question" value link  using Parameter
        public void ClickOnQuestionSearchResult(string trackingID)
        {
            ReadOnlyCollection<IWebElement> rowEle = driver.FindElements(By.XPath("//table[@class='table table-bordered table-hover faq-table']/tbody/tr"));
            int rowCount = rowEle.Count;

            for (int i = 1; i <= rowCount; i++)
            {
                IWebElement TrackingIDEle = driver.FindElement(By.XPath("//table[@class='table table-bordered table-hover faq-table']/tbody/tr[" + i + "]/td[1]"));
                if (TrackingIDEle.Text.Trim().Equals(trackingID) )
                {
                    IWebElement questionLoc = driver.FindElement(By.XPath("//table[@class='table table-bordered table-hover faq-table']/tbody/tr[" + i + "]/td[3]"));
                    Thread.Sleep(3000);
                    questionLoc.Click();
                    Thread.Sleep(1000);
                    break;
                }
            }
        }


        public bool CheckWithSingleSearch(string searchDetail, string cellDetail)
        {
            ReadOnlyCollection<IWebElement> rowEle = driver.FindElements(By.XPath("//table[@class='table table-bordered table-hover faq-table']/tbody/tr"));
            int rowCount = rowEle.Count;

            bool testResult = true;
            for (int i = 1; i <= rowCount; i++)
            {
                IWebElement srcEle = driver.FindElement(By.XPath("//table[@class='table table-bordered table-hover faq-table']/tbody/tr[" + i + "]/td["+ cellDetail + "]"));
                if (!srcEle.Text.Trim().ToLower().Contains(searchDetail.ToLower()))
                {
                    testResult = false;
                    break;
                }
            }
            return testResult;
        }


        public void ClickOnQuestionWithGivenParameter(string parameter)
        {
            ReadOnlyCollection<IWebElement> rowEle = driver.FindElements(By.XPath("//table[@class='table table-bordered table-hover faq-table']/tbody/tr"));
            int rowCount = rowEle.Count;

            for (int i = 1; i <= rowCount; i++)
            {
                IWebElement permRowEle = driver.FindElement(By.XPath("//table[@class='table table-bordered table-hover faq-table']/tbody/tr[" + i + "]"));
                if (permRowEle.Text.ToLower().Contains(parameter.ToLower()))
                {
                    IWebElement questionLoc = driver.FindElement(By.XPath("//table[@class='table table-bordered table-hover faq-table']/tbody/tr[" + i + "]/td[3]"));
                    Thread.Sleep(1000);
                    questionLoc.Click();
                    break;
                }
            }
        }

        public void ClickOnQuestionWithGivenParameter(string parameter1, string parameter2)
        {
            ReadOnlyCollection<IWebElement> rowEle = driver.FindElements(By.XPath("//table[@class='table table-bordered table-hover faq-table']/tbody/tr"));
            int rowCount = rowEle.Count;

            for (int i = 1; i <= rowCount; i++)
            {
                IWebElement permRowEle = driver.FindElement(By.XPath("//table[@class='table table-bordered table-hover faq-table']/tbody/tr[" + i + "]"));
                if (permRowEle.Text.ToLower().Contains(parameter1.ToLower()) && permRowEle.Text.ToLower().Contains(parameter2.ToLower()) )
                {
                    IWebElement questionEle = driver.FindElement(By.XPath("//table[@class='table table-bordered table-hover faq-table']/tbody/tr[" + i + "]/td[3]/a"));
                    Thread.Sleep(1000);
                    questionEle.Click();
                    //Console.WriteLine(questionEle.Text);
                    //questionEle.
                    //IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
                    //js.ExecuteScript("arguments[0].click();", questionEle);

                    break;
                }
            }
        }


        //public void SelectStage(string stage)
        //{
        //    ReadOnlyCollection<IWebElement> rowEle = driver.FindElements(By.XPath("//select[@id='search-workflow-stage']/option"));

        //    int rowCount = rowEle.Count;

        //    for (int i = 0; i <= rowCount; i++)
        //    {
        //        IWebElement workflowStageEle = driver.FindElement(By.XPath("//select[@id='search - workflow - stage']/option"));
        //        if (workflowStageEle.Text.Trim().Equals(stage))
        //        {
        //            IWebElement stageLoc = driver.FindElement(By.XPath("//select[@id='search - workflow - stage']/option[" + i + "]"));
        //            stageLoc.Click();
        //            break;
        //        }
        //    }
        //}

        public void SelectWorkflowStage(string stage)
        {
            IWebElement workflowStageEle = driver.FindElement(workflowStageLoc);
            SelectElement select = new SelectElement(workflowStageEle);
            select.SelectByText(stage);
            Thread.Sleep(1000);
            workflowStageEle.Click();
            Thread.Sleep(1000);
        }



    }
}


/*
 public bool CheckOnSearchWithSME(string smeDetail)
        {
            ReadOnlyCollection<IWebElement> rowEle = driver.FindElements(By.XPath("//table[@class='table table-bordered table-hover faq-table']/tbody/tr"));
            int rowCount = rowEle.Count;

            bool testResult = true;
            for (int i = 1; i <= rowCount; i++)
            {
                IWebElement smeEle = driver.FindElement(By.XPath("//table[@class='table table-bordered table-hover faq-table']/tbody/tr[" + i + "]/td[7]"));
                if (smeEle.Text.Trim().ToLower().Contains(smeDetail))
                {
                    IWebElement questionLoc = driver.FindElement(By.XPath("//table[@class='table table-bordered table-hover faq-table']/tbody/tr[" + i + "]/td[3]"));
                    questionLoc.Click();                   
                }
                else
                {
                    testResult = false;
                    break;
                }
            }
            return testResult;

        }
 */
