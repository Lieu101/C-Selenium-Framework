﻿using OpenQA.Selenium;


namespace QandA.Pages
{
    class SmePage
    {
        public IWebDriver driver;
        public SmePage(IWebDriver driver)
        {
            this.driver = driver;
        }

        //1 Click on All Radio Button
        private By allQandARadioBtnLoc = By.XPath("(//input[@id='searchFor'])[1]");

        //2 Enter trackingID
        private By trackingIDLoc = By.Id("tracking-id-search");



        public void ClickOnAllQARadioBtn()
        {
            IWebElement allQARadioBtnEle = driver.FindElement(allQandARadioBtnLoc);
            allQARadioBtnEle.Click();
        }

        //        Y140000637

        // Type  Tracking ID Text Box
        public void EnterTrackingID(string trackingId)
        {
            IWebElement trackingIdEle = driver.FindElement(trackingIDLoc);
            trackingIdEle.SendKeys(trackingId);
        }

    }
}
