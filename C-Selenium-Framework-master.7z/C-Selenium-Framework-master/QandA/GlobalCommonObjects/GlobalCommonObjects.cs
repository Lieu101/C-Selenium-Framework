﻿using System;
using System.Collections.Generic;
using System.Text;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System.Linq;
using System.Threading.Tasks;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Support.UI;
using NUnit.Framework;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Chrome;

namespace UnitTestProject_01
{
    class GlobalCommonObjects
    {
        //Keyword driven browser selection
        public void startwebdriverbrowsertype(string browser, string url)
        {
            if (browser == "internetexplore")
            {
                //Internet Explore
                IWebDriver driver = new InternetExplorerDriver();
                driver.Navigate().GoToUrl(url);

            }
            else if (browser == "chrome")
            {
                //Chrome driver
                IWebDriver driver = new ChromeDriver();
                driver.Navigate().GoToUrl(url);
            }
            else
            {
                //Firefox default
                IWebDriver driver = new FirefoxDriver();
                driver.Navigate().GoToUrl(url);
            }
        }
        //Open any web page by passing the driver
        public void OpenGoToPage(IWebDriver driver, string url)
        {

            driver.Navigate().GoToUrl(url);
        }

        //Close webdriver
        public void closedriver(IWebDriver driver)
        {
            driver.Close();
        }

        //Wait for document ready state to be complete
        public void waitforelementtoloadbyid(IWebDriver driver, string elementid)
        {
            IJavaScriptExecutor jse = (IJavaScriptExecutor)driver;
            int timeoutSec = 120;
            System.Threading.Thread.Sleep(5000);
            WebDriverWait wait = new WebDriverWait(driver, new TimeSpan(0, 0, timeoutSec));
            wait.Until(wd => jse.ExecuteScript("return document.readyState").ToString() == "complete");
            string jsescript = "document.getElementById(" + elementid + ")";
            jse.ExecuteScript(jsescript);
        }

        public void waitforelementtoloadbyname(IWebDriver driver, string elementname)
        {
            IJavaScriptExecutor jse = (IJavaScriptExecutor)driver;
            int timeoutSec = 120;
            System.Threading.Thread.Sleep(5000);
            WebDriverWait wait = new WebDriverWait(driver, new TimeSpan(0, 0, timeoutSec));
            wait.Until(wd => jse.ExecuteScript("return document.readyState").ToString() == "complete");
            string jsescript = "document.getEdlementByName (" + elementname + ")";
            jse.ExecuteScript(jsescript);
        }

        public void verifypagetext(IWebDriver driver, string elementtext)
        {
            IWebElement body = driver.FindElement(By.TagName("body"));
            Assert.IsTrue(body.Text.Contains(elementtext));
        }

    }
}
