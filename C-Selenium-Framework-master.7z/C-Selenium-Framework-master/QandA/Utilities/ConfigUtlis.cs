﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace Utilities
{
   public class ConfigUtlis
    {
        public static string GetValueFromConfig(string key)
        {
            string value = ConfigurationManager.AppSettings[key];
            return value;
        }
    }
}
