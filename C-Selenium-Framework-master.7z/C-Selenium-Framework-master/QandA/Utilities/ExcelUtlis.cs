﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excel = Microsoft.Office.Interop.Excel;
using Microsoft.CSharp.RuntimeBinder;

namespace Utilities
{
    class ExcelUtlis
    {
        public static DataTable SheetToDataTable(string excelLocation, string sheetName)
        {
            Excel.Application app = new Excel.Application();
            Excel.Workbook book = app.Workbooks.Open(excelLocation);
            Excel.Worksheet sheet = book.Sheets[sheetName];
            Excel.Range range = sheet.UsedRange;

            int rowCount = range.Rows.Count;
            int colCount = range.Columns.Count;

            DataTable dt = new DataTable();
            //Fill the column header from Excel to Datatable
            for (int j = 1; j <= colCount; j++)
            {
                string colHeader = range.Cells[1, j].value;
                dt.Columns.Add(colHeader);
            }
            //Fill the Row in the DayaTable
            for (int i = 2; i <= rowCount; i++)
            {
                DataRow row = dt.NewRow();
                for (int j = 1; j <= colCount; j++)
                {
                    //string cellValue = range.Cells[i, j].value;
                    string cellValue = range.Cells[i, j].value.ToString();
                    row[j - 1] = cellValue;
                }
                dt.Rows.Add(row);
            }
            book.Close();
            app.Quit();
            return dt;
        }

        public static object[] SheetIntoObject(string excelLocation, string sheetName)
        {
            DataTable dt = ExcelUtlis.SheetToDataTable(excelLocation, sheetName);
            int rowCount = dt.Rows.Count;
            int colCount = dt.Columns.Count;

            object[] main = new object[rowCount];

            for (int i = 0; i < rowCount; i++)
            {
                object[] temp = new object[colCount];

                for (int j = 0; j < colCount; j++)
                {
                    temp[j] = dt.Rows[i][j];
                }
                main[i] = temp;
            }
            return main;
        }


        //Added 11/04/2019
        public static void WriteToExcelSheet(string excelLocation, string sheetName, int rowNumber, int colNumber, String value)
        {

            Excel.Application app = null;
            Excel.Workbook book = null;
            try
            {
                app = new Excel.Application();

                book = app.Workbooks.Open(excelLocation);

                Excel.Worksheet sheet = book.Sheets[sheetName];

                Excel.Range range = sheet.UsedRange;

                range.Cells[rowNumber, colNumber].value = value;
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                book.Save();
                book.Close();
                app.Quit();
            }


        }

    }
}
