﻿using System;
using System.Data;
using Excel = Microsoft.Office.Interop.Excel;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Utilities
{
    class ExcelSheet
    {
        //public static  OpenExcel(string excelLocation, string sheetName)
        //public  OpenExcel()
        //{
        //    Excel.Application app = new Excel.Application();
        //    Excel.Workbook book = app.Workbooks.Open(excelLocation);
        //    Excel.Worksheet sheet = book.Sheets[sheetName];
        //    Excel.Range range = sheet.UsedRange;

        //    int rowCount = range.Rows.Count;
        //    int colCount = range.Columns.Count;
        //}

        //public bool WriteOnExcelSheet(string excelLocation, string sheetName, int columnNumber, string value)
        //{
        //    //OpenExcel();
        //    int sheetValue = 0;

        //    try
        //    {
        //        if (sheets..ContainsValue(sheetName))
        //        {
        //            foreach (DictionaryEntry sheet in sheets)
        //            {
        //                if (sheet.Value.Equals(sheetName))
        //                {
        //                    sheetValue = (Int32)sheet.Key;
        //                }
        //            }
        //            xl.Workbook
        //        }

        //    }
        //    catch (Exception ex)
        //    {
        //        return false;
        //    }

        //}



    }
}
